public class Prostokat {
    private double a;
    private double b;
    public Prostokat(double bokA,double bokB){
        this.a=bokA;
        this.b=bokB;
    }

    public void setB(double b) {
        this.b = b;
    }

    public double getB() {
        return b;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getA() {
        return a;
    }

    public double pole(){
        return this.a*this.b;
    }

    public static void main(String[] args) {
        Prostopadloscian elo=new Prostopadloscian(3,4,5);
        Prostokat latwo=new Prostokat(4,5);
        System.out.println(elo.pole());
        System.out.println(elo.objetosc());
        System.out.println(latwo.pole());

    }
}

