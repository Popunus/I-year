public class DrzewoIglaste extends Drzewo{
    int iloscIgiel;
    double dlugoscSzyski;
    public DrzewoIglaste(boolean wiecznieZielone, int wyskosc, String przekorjDrzewa,int iloscIgiel,double dlugoscSzyski){
        super(wiecznieZielone,wyskosc,przekorjDrzewa);
        this.dlugoscSzyski=dlugoscSzyski;
        this.iloscIgiel=iloscIgiel;
    }
    public String toString(){
        return super.toString()+"\n"+"dlugosc szyszki:"+dlugoscSzyski+"\n"+"ilosc igiel:"+ iloscIgiel;
    }
}
