public class Drzewo {
    boolean wiecznieZielone;
    int wyskosc;
    String przekorjDrzewa;
    public Drzewo(boolean wiecznieZielone,int wyskosc, String przekorjDrzewa){
        this.przekorjDrzewa=przekorjDrzewa;
        this.wiecznieZielone=wiecznieZielone;
        this.wyskosc=wyskosc;
    }

    public String toString(){
        return "czy drzewo jest wiecznie zielone: "+ wiecznieZielone+"\n"+
                "wysokosc: "+wyskosc+"\n"+"przekroj drzewa: "+przekorjDrzewa;
    }

    public static void main(String[] args) {
        Drzewo baobab=new Drzewo(true,20,"normalny");
        System.out.println(baobab.toString());
        DrzewoIglaste choinka=new DrzewoIglaste(true,100,"nienormalny",100,2.2);
        System.out.println(choinka.toString());
    }
}
