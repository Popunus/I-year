public class Ostroslup extends Trojkat {
    private double duzeh;
    public Ostroslup(double a, double h, double duzeh){
        super(a,h);
        this.duzeh=duzeh;
    }
@Override
    public double pole(){
        return (getA()*getA()*Math.sqrt(3))/4+3*(getA()*getH())/2;
    }
    public double objestosc(){
        return (getA()*getA()*duzeh*Math.sqrt(3))/12;
    }



}
