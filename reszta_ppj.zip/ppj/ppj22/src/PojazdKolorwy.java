public class PojazdKolorwy extends Pojazd{
    private int iloscOsi;
    public PojazdKolorwy(String color,int iloscOsi){
        super(color);
        this.iloscOsi=iloscOsi;

    }
}
