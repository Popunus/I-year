public class Prostopadloscian extends Prostokat{
    private double h;
    public Prostopadloscian(double bokA, double bokB, double wys) {
        super(bokA, bokB);
        this.h = wys;
    }
    @Override
    public double pole(){
        return 2*getA()*getB()+2*getA()*h+2*h*getB();
        }
    public double objetosc(){
        return getA()*getB()*h;
    }



    }

