public class CiagnikSiodlowy extends PojazdKolorwy{
    double masa;
    public CiagnikSiodlowy(String color, int iloscOsi,double masa){
        super(color,iloscOsi);
        this.masa=masa;
    }
    public void rozpocznijJazde(){
        if(masa>11)
            System.out.println("Jazda niebezpieczna, odmowa uruchomienia silnika");
    }
}
