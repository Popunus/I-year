public class Osoba {
    private String imie;
    public Osoba(String imie){
        this.imie=imie;
    }
    String wyswietl(){
        return imie;
    }

    public String getImie() {
        return imie;
    }

    public static void main(String[] args) {
        Osoba dziad=new Osoba("Henryk");
        System.out.println(dziad.wyswietl());
        Spawacz spawacz=new Spawacz("Gino",2);
        System.out.println(spawacz.wyswietl());
    }
}
