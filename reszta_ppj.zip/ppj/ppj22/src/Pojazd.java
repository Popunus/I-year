public class Pojazd {
    String color;
    public Pojazd(String color){
        this.color=color;
    }

    public static void main(String[] args) {
        CiagnikSiodlowy dziad=new CiagnikSiodlowy("magenta",8,11.1);
        dziad.rozpocznijJazde();
    }
}
