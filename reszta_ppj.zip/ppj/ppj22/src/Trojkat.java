public class Trojkat {
    private double a;
    private double h;
    public Trojkat(double a, double h){
        this.a=a;
        this.h=h;
    }
    public double pole(){
        return 1/2*h*a;
    }
    public double getH() {
        return h;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getA() {
        return a;
    }

    public void setH(double h) {
        this.h = h;
    }

    public static void main(String[] args) {
        Ostroslup dziad=new Ostroslup(3,4,5);
        System.out.println(dziad.objestosc());
        System.out.println(dziad.pole());
    }
}
