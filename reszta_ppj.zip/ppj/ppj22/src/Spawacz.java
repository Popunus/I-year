public class Spawacz extends Osoba{
    private int stazpracy;
    public Spawacz(String imie,int stazpracy){
        super(imie);
        this.stazpracy=stazpracy;
    }
    @Override
    String wyswietl(){
        return super.getImie() +" "+stazpracy;
    }
}
