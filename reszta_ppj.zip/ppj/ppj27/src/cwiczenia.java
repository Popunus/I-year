import java.util.Scanner;
public class cwiczenia {
    public static void main(String[] args) {
        Scanner liczba=new Scanner(System.in);
        int liczbasprawdz=liczba.nextInt();
        if(liczbasprawdz<0 || liczbasprawdz>2.147483648E9){
            System.out.println("nie podoba mi sie ta liczba!");
            return;
        }
        StringBuilder stringBuilder1 = new StringBuilder();

        char a='0';
        char b='1';

        while (liczbasprawdz>0){
        int i=liczbasprawdz;
            if(i%2==0) {
                stringBuilder1.append(b);
                liczbasprawdz = liczbasprawdz - i;
            }
            else
                stringBuilder1.append(a);
            liczbasprawdz/=2;
        }
        System.out.println(stringBuilder1);
    }
}
