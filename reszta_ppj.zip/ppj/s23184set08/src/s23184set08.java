public class s23184set08 {
    public static void main(String[] args) {
        System.out.println("task01");
        show(2);
        System.out.println("task02");
        int wrt=5;
        modifyValue(wrt);
        // metoda przeprowadziła zmiany na zmiennej jedank nawet po zmiannach w metodzie jej wartosc zostaje taka sama
        System.out.println("task03");
        char tab [] ={'A','l','a',' ','m','a',' ','k','o','t','a'};
        //zrozumialem ma liczyc tylko znaki nie whitespace
        tabCounter(tab);
        System.out.println("task04");
        int tab2[]=new int [10];
        int tab3[]=new int [10];
        for(int i=0;i<tab2.length;i++){
            tab2[i]=((int)(Math.random()*10));
        }
        for(int i=0;i<tab3.length;i++){
            tab3[i]=((int)(Math.random()*10));
        }
    }
    //metoda task01
    static void show(int num){
        System.out.println(num);
    }
    //metoda task02
    static void modifyValue(int zmienna){
        System.out.println(zmienna);
        zmienna=zmienna*5;
        System.out.println(zmienna);
    }
    //metoda task03
    static void tabCounter(char tab []){
        int sum=0;
        for(int i=0;i<tab.length;i++){
            if(tab[i]!=' ')
                sum++;
        }
        System.out.println(sum);
    }
    //metoda task04
    static void metodarrays(int tab[],int tab2[],int a){
        int max=0;
        if(tab.length> tab2.length)
            max= tab.length;
        else
            max=tab2.length;
        int finaltab []=new int [max];
        if(a<0){
            for(int i=0;i< finaltab.length;i++){
                finaltab[i]=tab[i]+tab2[i];
            }
            if(a>0){

            }
            if(a==0){
                System.out.println("null");
            }
        }
    }
    //metoda task05

}
