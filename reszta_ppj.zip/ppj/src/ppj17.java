public class ppj17 {
    public static void main(String[] args) {
    printMonth(2,2004);
        System.out.println();
        System.out.println("zad2");
    int arr[]={1,2,3,4};
    swap(arr,0,3);
    }
    public static void printMonth(int m,int y){
        int howmanydays;
        int goingup=1;
        if(m==2 && (y%4==0 || y%100==0))
            howmanydays=29;
        if(m==2 && (y%4!=0 || y%100!=0))
                howmanydays=28;
        if((m<8 && m%2!=0) || (m>=8 && m%2==0))
            howmanydays=31;
        else
            howmanydays=30;
        for(int i=1;i<=howmanydays;i++){
            if(i==1){
                System.out.print(goingup);
                goingup++;
            }
            if(i%7==0) {
                System.out.println();
                System.out.print(goingup);
                goingup++;
            }

            System.out.print("  "+i);

        }
    }
    public static void swap(int[ ]tab,int source,int destination){
        int temp=tab[source];
        tab[source]=tab[destination];
        tab[destination]=temp;
        for(int i=0;i< tab.length;i++){
            System.out.print(tab[i]+", ");
        }
    }
}
