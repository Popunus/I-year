public class ppj16 {
    public static void main(String[] args) {
        System.out.println("zad1");
        System.out.println(splitToDigits(5)[0]);
        System.out.println(splitToDigits(6)[1]);
        System.out.println("zad2");
        System.out.println(isArmstrongNumber(153));

    }

    public static int[] splitToDigits(int number) {

        int array[] = new int[10];
        int goingup = 0;
        array[goingup] = number;
        goingup++;
        return array;
    }

    public static boolean isArmstrongNumber(int number) {
        int howlong = number;
        int rebrand = number;
        int mark = 0;
        double result = 0;
        while (howlong > 0) {
            howlong /= 10;
            mark++;
        }
        while (rebrand > 0) {
            result += Math.pow((double) (rebrand % 10), (double) mark);
            rebrand /= 10;
        }
        if (result == number)
            return true;
        else
            return false;
    }
}
 /*   public static int[][] calculateSquares(int screenWidth, int screenHeight, int side){
        int squareHeight=screenHeight/side;
        int squareWidth=screenWidth/side;
        int howMany=squareHeight*squareWidth;
        int square_array[][]=new int[2][howMany];

        for(int i=0;i<squareWidth;i++){
            for(int j=0;j<squareHeight;j++){
                if(i==0 && j==0) {
                    square_array[0][0] = 0;
                    square_array[1][0] = side;
                }
                if
        }





    }
}*/
