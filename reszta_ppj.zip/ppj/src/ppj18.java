public class ppj18 {
    public static void main(String[] args) {

    }
}
