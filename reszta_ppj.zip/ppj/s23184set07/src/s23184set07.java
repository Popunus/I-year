public class s23184set07 {
    public static void main(String[] args) {
        int temp;
        int tab[][]=new int[10][10];
        for(int i=0;i<tab.length;i++){
            for(int j=0;j< tab[i].length;j++){
                tab[i][j]=(int)(Math.random()*10);
            }
        }
        for(int i=0;i<tab.length;i++){
            for(int j=0;j< tab[i].length;j++){
                if(tab[i][j] > tab[i][j + 1]){
                    temp = tab[i][j];
                    tab[j] = tab[j + 1];
                    tab[i][j + 1] = temp;
                }
            }
        }
        for(int i=0;i<tab.length;i++){
            for(int j=0;j< tab[i].length;j++){
                System.out.println(tab[i][j]);
            }
        }
    }
    void task01(){
        int tab1[]=new int [(int)(Math.random()*10)];
        int tab2[]=new int [(int)(Math.random()*10)];
        int tab3[]=new int [(int)(Math.random()*10)];
        for(int i=0;i< tab1.length;i++){
            tab1[i]=(int)(Math.random()*10);
        }
        for(int i=0;i< tab2.length;i++){
            tab2[i]=(int)(Math.random()*10);
        }
        for(int i=0;i< tab3.length;i++){
            tab3[i]=(int)(Math.random()*10);
        }
        int TAB[][]=new int[3][10];
        for(int i=0;i<TAB.length;i++){
            for(int j=0;j< TAB[i].length;j++){
                if(i==0)
                    TAB[i][j]=tab1[j];
                if(i==1)
                    TAB[i][j]=tab2[j];
                if(i==2)
                    TAB[i][j]=tab3[j];
            }
        }
        for(int i=0;i<TAB.length;i++){
            for(int j=0;j< TAB[i].length;j++){
                System.out.println(TAB[i][j]);
            }
        }
    }
    void task02() {
        int wzrost=0;
        int spadek=8;
        int wzrostek=0;
        int warunek=0;
        int tab2[]=new int[16];
        int tab[][]=new int[8][8];
        for(int i=0;i<tab.length;i++){
            for(int j=0;j< tab[i].length;j++){
                tab[i][j]=(int)(Math.random()*10);
            }
    }
        for(int i=0;i<tab.length;i++){
            for(int j=0;j< tab[i].length;j++){
                if(i==j){
                    tab2[wzrost]=tab[i][j];
                    wzrost++;
                }
                if(j==spadek && i==wzrostek){
                    tab2[wzrost]=tab[i][j];
                    wzrost++;
                    spadek--;
                    wzrostek++;
                }
            }
        }
        for(int j=0;j<10;j++){
            for(int i=0;i<tab2.length;i++){
                if(tab2[i]==j){
                    warunek++;
                }
            }
            if(warunek>=3){
                System.out.println("warunek wystepuje");
            }
            warunek=0;
        }
    }
    void task04() {
        int temp;
        int tab[][]=new int[10][10];
        for(int i=0;i<tab.length;i++){
            for(int j=0;j< tab[i].length;j++){
                tab[i][j]=(int)(Math.random()*10);
            }
        }
        for(int i=0;i<tab.length;i++){
            for(int j=0;j< tab[i].length;j++){
                if(tab[i][j] > tab[i][j + 1]){
                    temp = tab[i][j];
                    tab[j] = tab[j + 1];
                    tab[i][j + 1] = temp;
                }
            }
            }
        for(int i=0;i<tab.length;i++){
            for(int j=0;j< tab[i].length;j++){
                System.out.println(tab[i][j]);
            }
        }
    }
}

