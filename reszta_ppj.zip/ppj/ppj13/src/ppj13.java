import java.util.Scanner;

public class ppj13 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int size = 4;
        int totalSize = 2 * size + 1;

        for (int rowIndex = 0; rowIndex < totalSize; rowIndex++) {
            boolean upperHalf = rowIndex <= totalSize / 2;
            int totalDots = upperHalf ? totalSize - (rowIndex * 2 + 1) : (rowIndex - size) * 2;

            for (int j = 0; j < totalDots / 2; j++) System.out.print('.');
            for (int j = 0; j < totalSize - totalDots; j++) System.out.print('*');
            for (int j = 0; j < totalDots / 2; j++) System.out.print('.');
            System.out.println();
        }
    }
    public void task03(){
        int tab1[] = new int[10];
        double tab2[] = new double[10];
        for (int i = 0; i < 10; i++) {
            tab1[i] = (int) (Math.random() * 15);
            tab2[i] = Math.random() * 15;
        }

        for (int i = 0; i < 10; i++)
        {

            int min_idx = i;
            for (int j = i+1; j < 10; j++)
                if (tab1[j] + tab2[j] < tab1[min_idx] + tab2[min_idx])
                    min_idx = j;





            int temp1 = tab1[min_idx];
            double temp2=tab2[min_idx];
            tab1[min_idx] = tab1[i];
            tab2[min_idx] = tab2[i];
            tab1[i] = temp1;
            tab2[i]=temp2;

        }
        for(int i=0;i<10;i++){
            System.out.println(tab1[i]+tab2[i]);
        }
    }
}
