public class DetektorDymu {
    boolean dym;
    public DetektorDymu(boolean dym){
        this.dym=dym;
    }
    public boolean sprawdz() throws Exception{
        if(dym==true){
            throw new Exception("alarm, ale dymy!");
        }
            return dym;
    }
}
