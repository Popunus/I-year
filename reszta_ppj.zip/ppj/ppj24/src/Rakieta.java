public class Rakieta extends Exception {
    String nazwa;
    int wagaPaliwa;
    int ilePaliwa;
    public Rakieta(String nazwa, int wagaPaliwa){
        this.nazwa=nazwa;
        this.wagaPaliwa=wagaPaliwa;
    }
    public int zatankuj(){
        int random=((int)(Math.random()*100))*1000;
        ilePaliwa=random;
        return ilePaliwa;
    }
    public boolean start() throws Exception{
        if(ilePaliwa<1000){
            throw new Exception("start anulowany - za mało pa-liwa");
        }
        return true;
    }

    public static void main(String[] args) throws Exception {
        Rakieta sokoli=new Rakieta("sokoliv2",1);
        System.out.println(sokoli.zatankuj());
        sokoli.start();
    }
}
