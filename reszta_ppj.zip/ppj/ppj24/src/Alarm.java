public class Alarm extends Exception{

}
