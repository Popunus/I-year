public class ppj24 {
    public static void main(String[] args) throws Exception {
    DetektorDymu dymometr=new DetektorDymu(true);
    dymometr.sprawdz();
    }

}
