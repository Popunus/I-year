public class S23184_p01 {
    public static void main(String[] args) {


        char[] tablica1 = {'1', '2', '3', '4'};


        char[] tablica2 = {'1', '2', '2','2'};


        calc(tablica1, tablica2, '-', 2);
        // posiada zabezpieczenie w przypadku podania zlego operatora oraz systemu



    }

    public static void calc(char[] number1, char[] number2, char operator, int system) {
        int liczba1 = 0;
        int liczba2 = 0;
        int wynik =0;

        //zmieniam ciag znakow na int-a by ułatwic sobie obliczenia
        for (int i = 0; i < number1.length; i++) {
            liczba1 += (int) number1[i] - 48;
            if (i != number1.length - 1)
                liczba1 *= 10;
        }
        for (int i = 0; i < number2.length; i++) {
            liczba2 += (int) number2[i] - 48;
            if (i != number2.length - 1)
                liczba2 *= 10;
        }

        if (operator == 43) {
            while (liczba2 > 0) {

                int temp = liczba1 & liczba2; // bierze wspolny zestaw bitow


                wynik = liczba1 ^ liczba2; // sumuje bity


                liczba2 = temp << 1;  //przesuwamy zmienna o 1
            }
            System.out.println(wynik);
        }
        if (operator == 45) {
            while (liczba2 > 0) {

                int temp = (~liczba1) & liczba2; //bierze wspolny zestaw bitow odwrocej liczby1 i liczby2


                wynik = liczba1 ^ liczba2; //sumuje bity


                liczba2 = temp << 1; //przesuniecie zmiennej o 1
            }
            System.out.println(wynik);
        }

        if(operator!=45 && operator!=43){
            System.out.println("zly operator");
            return;
        }
        if(system>=2 && system<=16) {
            int suma;                        // Sluzy do znalezenia cyfry systemu liczbowego i przypisania go do tablicy
            int zmienna = wynik;             //zmienna jest wykorzystana w celu okereslenia ilosci cyfr
            int a = 0;                       // przypisuje go do tablicy by okreslic z ile elementow ma sie skladac
            int b = 0;                       // zmienna ta idzie rosnaco po talibcy char
            while (zmienna > 0) {
                zmienna = zmienna / system;
                a++;
            }
            char tab[] = new char[a];

            while (wynik > 0) {
                suma = wynik % system;
                wynik /= system;
                tab[b] = (char) (suma + 48);
                if (suma == 10)
                    tab[b] = 'A';
                if (suma == 11)
                    tab[b] = 'B';
                if (suma == 12)
                    tab[b] = 'C';
                if (suma == 13)
                    tab[b] = 'D';
                if (suma == 14)
                    tab[b] = 'E';
                if (suma == 15)
                    tab[b] = 'F';
                b++;
            }
            for (int i = tab.length - 1; i >= 0; i--) {   //tablica wypisano malejaco jako ze elementy byly obliczane od najwiekszego
                System.out.print(tab[i] + " ");
            }
        }
        else System.out.println("podano zly system");
    }
}