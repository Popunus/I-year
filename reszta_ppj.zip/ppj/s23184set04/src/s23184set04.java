import java.util.*;
public class s23184set04 {

    public void task01() {
        int i= 10;
        i=i++;
        // 11 a wychodzi 10
        i= ++i;
        //11 a wychodzi 11
        i=i++ + ++i;
        // 21 a wychodzi 22 nie wiem dlaczego
    }
    public void task02() {
        // rezultatem bedzie  blad bo nie ma wartosci a
    }
    public void task03() {
        //zmDouble jest mniejsza od zero wiec przechodzimy do else ktore wypisze "No, I am here!" i tez wypisze sie No, actually , I am here!
    }
    public void task04(){
        boolean doesSignificantWork, makesBreakthrough, nobelPrizeCandidate;
        doesSignificantWork=true;
        makesBreakthrough=true;
        if(doesSignificantWork&&makesBreakthrough==true)
            nobelPrizeCandidate=true;
        else
            nobelPrizeCandidate=false;
        boolean kandydat=true;

        if(kandydat==true)
            nobelPrizeCandidate=true;
        else
            nobelPrizeCandidate=false;


    }
    public void task05(){
        //a=b poniewaz naraz jest warunek ze a nie moze byc i wiekszy i mniejsze czyli musi byc rowne
    }
    public void task06(){
        int a,b,c;
        a=0;
        b=0;
        c=1;

        String prawda=a==b ? "sa takie same":"nie sa takie same";
        System.out.println(prawda);
        String falsz=c==b ? "sa takie same":"nie sa takie same";
        System.out.println(falsz);
    }
    public void task07(){
        Scanner scanner = new Scanner(System.in);
        int M=scanner.nextInt();
        int D=scanner.nextInt();


                if(M>3 && M<6 ||M==3&&D>=21 || M==6 && D<= 20)
                    System.out.println("Wiosna");

                if(M>6 && M<9 ||M==6&&D>=21 || M==9 && D<= 22)
                System.out.println("Lato");

                if(M>9 && M<12 ||M==9&&D>=23 || M==12 && D<= 21)
                System.out.println("Jesieon");

                if(M<3 ||M==12&&D>=22 || M==3 && D<= 20)
                System.out.println("Zima");
    }
    public void task08(){
        int a=0;
        if(a>=0)
            System.out.println("nalezy do zbioru A");
        if(a<=1)
            System.out.println("nalezy do zbioru B");
        if(a<=1 && a>=0)
            System.out.println("nalezy do zbioru c");
    }
    public void task09(){
        int wrt =0;
        if(wrt>-15 && wrt<=-10 || wrt>-5 && wrt<0 || wrt>5 &&wrt<10){
            if(wrt<=-13 || wrt>-8 && wrt<=-3){
                if(wrt>=-4)
                    System.out.println("nalezy do zbiorow");
            }
        }
        else
            System.out.println("nie nalezy do zbiorow");
    }
    public void task10(){
        int wrt=0;
        if(wrt>-15 && wrt<-10 ^ wrt< -13){
            System.out.println("nalezy do jednego zbioru");
        }
        else
        System.out.println("nie nalezy tylko do jednego zbioru");
    }

}
