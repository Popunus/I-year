import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.IOException;


public class Main {


    public static void main(String[] args) throws IOException {

        BufferedImage zdjecie = ImageIO.read(new File("C:\\Users\\kubal\\IdeaProjects\\projekt_dodatkowy-s23184\\src\\grayFisheye.png")); //load the image from this current folder

        final byte[] data = ((DataBufferByte) zdjecie.getRaster()

                .getDataBuffer()).getData();

        final int width = zdjecie.getWidth();

        final int height = zdjecie.getHeight();

        int[][] result = new int[height][width];

        for (int pixel = 0, row = 0, col = 0; pixel < data.length; pixel++) {

            int temp = 0;

            temp = data[pixel];

            if (temp < 0) {
                temp += 256;
            }



            result[row][col] = temp;

            col++;


            if (col == width) {

                col = 0;

                row++;

            }

        }
        System.out.println("Narożniki to:");
        System.out.println("1: 0 wiersz,0 kolumna: "+result[0][0]);
        System.out.println("2: 1080 wiersz,0 kolumna: "+result[height-1][0]);
        System.out.println("3: 1080 wiersz,1920 kolumna: "+result[height-1][width-1]);
        System.out.println("4: 0 wiersz,1920 kolumna: "+result[0][width-1]);


    }
}
