public class Person {
    String name;
    int birthYear;
    public Person(String temp_name,int temp_birth){
        this.name=temp_name;
        this.birthYear=temp_birth;
    }
    public Person(String temp_name){
        this.name=temp_name;
        this.birthYear=1990;
    }
    public String getName(){
        return this.name;
    }
    public int getAge(){
        return this.birthYear;
    }
    public static int getOlder(Person a,Person b){
        if(a.birthYear<b.birthYear)
            return a.birthYear;
        else
            return b.birthYear;

    }
    public static int getOldest(Person [] arr){
        int oldest=arr[0].birthYear;
        for(int i=0;i<arr.length;i++){
            if(oldest>arr[i].birthYear)
                oldest=arr[i].birthYear;
        }
        return oldest;
    }

    public static void main(String[] args) {
        Person a=new Person("elo1",2001);
        Person b=new Person("elo2",2122);
        Person c=new Person("elo3",2010);
        Person d=new Person("eloo4");
        Person [] arr={a,b,c,d};
        System.out.println(Person.getOldest(arr));
        System.out.println();
        System.out.println(Person.getOlder(a,b));
        System.out.println();
        System.out.println(a.getAge());
        System.out.println();
        System.out.println(a.getName());
    }
}
