public class Phrase {
    Phrase arr [];
    int queue=0;
    public Phrase(String temp_task){
       arr[queue]=temp_task;
       queue++;
    }
    public  void addWordAtEnd(Word a){
        arr[queue]=a;
    }


}
