public class Word {
    int queue=0;
    char [] char_arr;
    int temp_int;
    public Word(){
        this.char_arr=new char[100];
        this.temp_int=0;
    }
    public void addChar(char add){
        char_arr[queue]=add;
        queue++;
    }
    public void show(){
        for(int i=0;i<char_arr.length;i++){
            if(char_arr[i]!=0)
            System.out.print(char_arr[i]+", ");
        }
    }
    public int length(){
        return queue;
    }

    public static void main(String[] args) {
        Word abba=new Word();
        abba.addChar('a');
        abba.addChar('b');
        abba.addChar('c');
        abba.addChar('d');
        abba.addChar('e');
        System.out.println();
        System.out.println(abba.length());
        System.out.println();
        abba.show();
    }



}
