import java.io.*;

public class main {
    public static void main(String[] args) {
        int liczbaplikow = 3;
        for (int i = 1; i <= liczbaplikow; i++) {
            File inputDataX = new File("inputData" + i + ".txt");
        }
        try {
            for (int i = 1; i <= liczbaplikow; i++) {
                File inputDataX = new File("inputData" + i + ".txt");
                inputDataX.createNewFile();
                BufferedWriter writer = new BufferedWriter(new FileWriter("inputData" + i + ".txt"));
                BufferedReader reader = new BufferedReader(new FileReader("inputData" + i + ".txt"));
                int temp;
                String zmienna;
                for(int j=0;j<10;j++){
                    temp=(int)(Math.random()*10000);
                    zmienna=String.valueOf(temp);;
                    writer.write(zmienna);
                    writer.newLine();

                }
                int [] array=new int[10];
                int up=0;
                while((reader.readLine())!=null){
                    zmienna=reader.readLine();
                    array[up]=Integer.parseInt(zmienna);
                    up++;
                }
                int min;
                for(int k=0;k<10;k++){
                    for(int l=k+1;l<10;l++){
                        if(array[k]<array[l]){
                            min=array[l];
                            array[l]=array[k];
                            array[k]=min;
                        }
                    }
                }
                for(int q=0;q<10;q++){
                    writer.write(array[i]);
                    writer.newLine();
                }



                writer.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
