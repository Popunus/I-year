public class Jablko extends  Owoc{
    public Jablko(String nazwa){
        super(nazwa);
        getMasa();
    }
    public String toString(){
        return getClass()+" "+ nazwa+ " "+masa;
    }
}
