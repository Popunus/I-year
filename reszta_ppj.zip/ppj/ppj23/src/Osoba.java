public class Osoba {
    String imie;
    String nazwisko;
    String numer;
    public Osoba(String imie, String nazwisko, String numer,){
        this.imie=imie;
        this.numer=numer;
        this.nazwisko=nazwisko;
    }

}
