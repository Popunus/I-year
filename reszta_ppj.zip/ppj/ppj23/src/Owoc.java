public class Owoc {
    String nazwa;
    double masa;
    public Owoc(String nazwa){
        this.nazwa=nazwa;
    }

    public double getMasa() {
        return this.masa=Math.random()*151+100;
    }

    public String toString(){
        return getClass()+" "+ nazwa+ " "+masa;
    }

    public static void main(String[] args) {
        Gruszka grucha=new Gruszka("zielona");
        System.out.println(grucha.toString());
    }
}
