public class KOMORKA extends Telefon{
    String [] historia=new String[10];
    int zmienna=0;
    public KOMORKA(String interfejsKomunikacyjny, String color){
        super(interfejsKomunikacyjny,color);
    }
    public void zadzwon(String numer){
        System.out.println(numer);
        historia[zmienna]=numer;
        zmienna++;
    }

}
