public class Smartfon extends KOMORKA{
    Osoba[] znajomi;
    int zmienna=0;
    public Smartfon(String interfejsKomunikacyjny, String color) {
        super(interfejsKomunikacyjny, color);
    }
    public Osoba [] dodaj(Osoba a){
        znajomi[zmienna]=a;
        zmienna++;
        return znajomi;
    }

}
