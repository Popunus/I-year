public class Gruszka extends Owoc {
    public Gruszka(String nazwa) {
        super(nazwa);
        getMasa();
    }

    public String toString() {
        return getClass() + " " + nazwa + " " + masa;
    }
}
