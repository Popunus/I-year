public class Pomarancza extends Owoc{
    public Pomarancza(String nazwa){
        super(nazwa);
        getMasa();
    }
    public String toString(){
        return getClass()+" "+ nazwa+ " "+masa;
    }
}
