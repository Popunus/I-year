public class Telefon {
    String interfejsKomunikacyjny;
    String color;
    public Telefon(String interfejsKomunikacyjny,String color){
        this.color=color;
        this.interfejsKomunikacyjny=interfejsKomunikacyjny;
    }
    public void zadzwon(String numer){
        System.out.println(numer);
    }
}
