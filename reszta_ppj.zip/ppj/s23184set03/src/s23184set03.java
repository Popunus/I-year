public class s23184set03 {

    public void task01()
    {
        byte a;
        a = -128;
        a = 127;
        a = 0b1111111;

        short b;
        b = -32768;
        b = 32767;
        b = 0b111111111111111;
        b = 077777;

        int c;
        c = -2147483648;
        c = 2147483647;
        c = 0b10000000000000000000000000000000;
        c = 0b1111111111111111111111111111111;

        long d;
        d = -9223372036854775808L;
        d = 9223372036854775807L;
        d = 0b1000000000000000000000000000000000000000000000000000000000000000L;
        d = 0b0111111111111111111111111111111111111111111111111111111111111111L;
        d = 0777777777777777777777L;//MAX VALUE

        double e;
        e = 4.9E-324;
        e = 1.7976931348623157E308;

        float f;
        f = 1.4E-45f;
        f = 3.4028235E38f;

        char g;
        g = '\u0000';
        g = '\uffff';

        boolean h;

        h = false;
        h = true;

    }

    public void task02()

    {
        boolean a = true;
        int b = 127;
        double c = 200.8;
        byte d = 1;
        //a==b;
        //b==c;
        //c==d;
    }



    public void task03()
    {
        //int a = a123;
        //int b = 1ppj;
        //int c = @azzzz;

        //int static = 123;
        //int d = "null";
    }
    public void task04()
    {
        int a = 100;
        System.out.println(a);

    }
    public void task05()
    {
        char charValue = 'a';
        char charvalue = 'b';

        /*skompiluje sie wielkosc znaku tez ma znaczenie;*/

    }
    public void task06()
    {
        int a = 18;
        double b = 1.2;
        //a=b; int nie obsluzy double ze wzgledu ze jego konstrukcja uwzglednia wartosci po kropce int natomiast nie
        b=a;
    }
    public void task07()
    {

        char a = 'A';
        int b = 1;
        float c = 3.19f;
        double d = 1.1;
        byte e = 127;

        a += b;
        System.out.println(a);
        b += a;
        System.out.println(b);
        c += d;
        System.out.println(c);
        e += b;
        System.out.println(e);

    }
}
