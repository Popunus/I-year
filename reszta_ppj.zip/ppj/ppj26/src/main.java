import java.util.regex.*;
public class main {
    public static void main(String[] args) {
        Pattern p = Pattern.compile("[A-Z]\\.[A-Z]\\.[A-Z]\\.[A-Z]\\.");
        String elo = "A.B.C.D.";
        Matcher m = p.matcher(elo);
        boolean b = m.matches();
        System.out.println(b);
    }
}
