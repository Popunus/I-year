public class s23184set06 {
    public void task01(){
        int tab[]=new int [10];
    }
    public void task02(){
        int tab[]=new int [10];
        for(int i=0;i<10;i++){
            double a=Math.random();
            tab[i]=a>0.5?1:0;
        }
    }
    public void task03(){
        int zmienna1=0;
        int zmienna2=0;
        int tab[]=new int [10];
        for(int i=0;i<10;i++){
            double a=Math.random();
            tab[i]=a>0.5?1:0;
            if(tab[i]==1)
                zmienna1++;
            if(tab[i]==0)
                zmienna2++;
        }
        System.out.println("1 wystepuje :"+zmienna1);
        System.out.println("0 wystepuje:"+zmienna1);
    }
    public void task04(){
        double tab[]=new double  [10];
        for(int i=0;i<10;i++){
            tab[i]=Math.random()*10;
            System.out.println(tab[i]);
            if(tab[i]%2==0)
                System.out.println(tab[i]);
            if(((int)tab[i])%2!=0)
                System.out.println(tab[i]);
        }
    }
    //task05 wypisze blad albo 0
    //task06 wypisze 3 razy 0 bo element i jest taki sam jak j

    public void task07(){
        String[ ] slowa= {"Ala","kota","ma","ma","a","kot","Ale"};
        for(int i=0;i< slowa.length;i++){
            System.out.print(slowa[i]+" ");
        }

    }
    public void task08(){
        char tab[]=new char [10];
        char tab2[]=new char [10];
        for(int i=0;i< tab.length;i++){
            tab[i]=((char)((((int)Math.random())*10+65)));
            for(int j=10;j<tab2.length;j++){
                tab2[j]=tab[i];
            }
        }
        for(int i=0;i<tab2.length;i++){
            System.out.println(tab2[i]);
        }
    }
}
