public class s23184set05 {


    public void task01() {
        //zad 1
        int K = 987654321;
        String s = " ";
        while (K != 0) {
            int cyfra = K % 10;
            s = s + cyfra;
            K = K / 10;
// zostanie wypisane 98765432

        }
    }

    public void task02() {
        int s = 0;
        int i = 1;
        while (i <= 10) {
            s = s + i;
            {
                System.out.println(s);

            }
            i++;
        }
    }

        public void task03 () {
        int i =0;
            do {
                i++;
                System.out.println(i);
            }
            while(i>0);

            while(i>0){
                System.out.println(i);
                i++;
            }




        }


        public void task04 () {
            for (double n = 0; n < 10; n++) {
                double a = 0.5;
                System.out.println(Math.pow(a, n));
            }
        }

        public void task05 () {

            int wrt = 5;
            for (int i = 0; i < 10; i++) {
                double a = 0.5;
                double wynik=Math.pow(a, i);
                System.out.println(wrt * wynik);
            }
        }

        public void task06 () {
            for (int i = -1500; i < 1500; i++) {
                if (i % 2 == 0 && i % 3 == 0)
                    System.out.println(i);

            }
        }

        public void task07 () {

            for (int i=1; i <= 5; i++) {
                int zmienna=i;
                while(zmienna>0){
                        System.out.print("*");
                        zmienna--;

                }
                System.out.println();
            }

        }
    }
