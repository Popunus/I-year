

public class StringTask implements Runnable {

    private TaskState currentState;
    private String stringToMultiply="";
    private int howMany;
    private String resultString;
    private Thread task;
    private volatile boolean taskShouldBeRunning;

    public StringTask(String stringToMultiply,int howMany) {
        this.howMany = howMany;
        this.currentState = TaskState.CREATED;
        this.task = new Thread(this);
        this.taskShouldBeRunning = false;
        this.resultString = "";
        for (int i = stringToMultiply.length() - 1; i >= 0; i--) {
            this.stringToMultiply = this.stringToMultiply + stringToMultiply.charAt(i);
        }
    }

    public void start() {

        taskShouldBeRunning=true;
        task.start();
    }

    public String getResult() {
        return resultString;

    }

    public TaskState getState() {
        return currentState;
    }
    public boolean isDone() {
        if(currentState.equals(TaskState.READY)||currentState.equals(TaskState.ABORTED))
            return true;

        return false;
    }

    @Override
    public void run() {
        multiplyString();
    }

    private void multiplyString() {
        while(taskShouldBeRunning) {
            int helper=howMany;
            for(int i=0;i<helper && taskShouldBeRunning;i++) {
                currentState=TaskState.RUNNING;
                resultString+=stringToMultiply;
                howMany--;
            }
            if(howMany==0) {
                currentState=TaskState.READY;
                return ;
            }
        }
        currentState=TaskState.ABORTED;
    }


    public String getTxt() {
        return stringToMultiply;
    }
}
