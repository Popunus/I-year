import java.lang.Thread;

public class InterruptionThread extends Thread {

    private TaskState taskToAbort;

    public InterruptionThread(StringTask taskToAbort) {
        this.taskToAbort=taskToAbort.getState();
    }

    @Override
    public void run() {
        try {
            Thread.sleep(1000);
            taskToAbort.abort();

        } catch (InterruptedException e) {
            e.printStackTrace();
            return;
        }

    }

}