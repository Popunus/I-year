public enum TaskState {
    CREATED,RUNNING,ABORTED,READY;

    public void abort() {

    }
}