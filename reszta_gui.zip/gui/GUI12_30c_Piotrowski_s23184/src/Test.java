

import java.awt.*;
import java.awt.event.*;

import javax.swing.JFrame;

import javax.swing.*;
import java.io.File;

public class Test implements ActionListener {
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new Test());
    }
    JPanel panel;
    JMenuItem item1;
    JMenuItem item2;
    JMenuItem item3;
    JMenuItem item4;
    JFrame frame;

    public  Test(){
        //tworzenie framea
        this.frame=new JFrame();
        JMenuBar menuBar=new JMenuBar();
        JMenu menu1, menu2,menu3;



        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(420,420);

        //dodanie scrollpane
        JTextArea text = new JTextArea();
        text.setLayout(new BorderLayout());
        JPanel text_panel = new JPanel(new BorderLayout());
        text.setSize(text.getPreferredSize());
        text.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        text_panel.add(text, BorderLayout.CENTER);
        JScrollPane scrollPane = new JScrollPane(text_panel);
        frame.add(scrollPane);

        //podstawowe menu
        menu1=new JMenu("File");
        menuBar.add(menu1);
        menu2=new JMenu("Edit");
        menuBar.add(menu2);
        menu3=new JMenu("Options");
        menuBar.add(menu3);

        //rozwiniecie menu file
        frame.setJMenuBar(menuBar);
        this.item1=new JMenuItem("Open");
        this.item1.setAccelerator(KeyStroke.getKeyStroke('O', InputEvent.CTRL_MASK,true));
        this.item1.addActionListener(this);
        menu1.add(item1);
        this.item2=new JMenuItem("Save");
        this.item2.setAccelerator(KeyStroke.getKeyStroke('S', InputEvent.CTRL_MASK,true));
        this.item2.addActionListener(this);
        menu1.add(item2);
        this.item3=new JMenuItem("Save As");
        this.item3.setAccelerator(KeyStroke.getKeyStroke('A', InputEvent.CTRL_MASK,true));
        this.item3.addActionListener(this);
        menu1.add(item3);
        this.item4=new JMenuItem("Exit");
        this.item4.setAccelerator(KeyStroke.getKeyStroke('X', InputEvent.CTRL_MASK,true));
        this.item4.addActionListener(this);
        JSeparator jSperator1= new JSeparator();
        jSperator1.setForeground(new java.awt.Color(255, 51, 51));
        menu1.add(jSperator1);

        menu1.add(item4);

        //rozwiniecie menu edit
        JMenu menu5=new JMenu("Adresy");
        menu2.add(menu5);
        JMenuItem item5=new JMenuItem("Praca");
        item5.setAccelerator(KeyStroke.getKeyStroke('P', InputEvent.CTRL_MASK+InputEvent.SHIFT_MASK));
        item5.addActionListener(e -> text.append("Warszawa ul.pracusia 8 kod pocztowy 05-420"));
        menu5.add(item5);
        JMenuItem item7=new JMenuItem("Dom");
        item7.setAccelerator(KeyStroke.getKeyStroke('D', InputEvent.CTRL_MASK+InputEvent.SHIFT_MASK));
        item7.addActionListener(e -> text.append("Warszawa ul.domowa 4 kod pocztowy 05-240"));
        menu5.add(item7);
        JMenuItem item8=new JMenuItem("Szkoła");
        item8.addActionListener(e -> text.append("Warszawa ul.szkolna 1 kod pocztowy 08-428"));
        item8.setAccelerator(KeyStroke.getKeyStroke('S', InputEvent.CTRL_MASK+InputEvent.SHIFT_MASK));
        menu5.add(item8);

        //rozwiniecie menu options
        JMenu menu6=new JMenu("Foreground");
        menu3.add(menu6);
        JRadioButtonMenuItem r1=new JRadioButtonMenuItem("green");
        r1.setForeground(Color.green);
        r1.addActionListener(e -> text.setForeground(Color.green));
        JRadioButtonMenuItem r2=new JRadioButtonMenuItem("orange");
        r2.setForeground(Color.orange);
        r2.addActionListener(e -> text.setForeground(Color.orange));
        JRadioButtonMenuItem r3=new JRadioButtonMenuItem("red");
        r3.setForeground(Color.red);
        r3.addActionListener(e -> text.setForeground(Color.red));
        JRadioButtonMenuItem r4=new JRadioButtonMenuItem("black");
        r4.setForeground(Color.black);
        r4.addActionListener(e -> text.setForeground(Color.black));
        JRadioButtonMenuItem r5=new JRadioButtonMenuItem("white");
        r5.setForeground(Color.white);
        r5.addActionListener(e -> text.setForeground(Color.white));
        JRadioButtonMenuItem r6=new JRadioButtonMenuItem("yellow");
        r6.setForeground(Color.yellow);
        r6.addActionListener(e -> text.setForeground(Color.yellow));
        JRadioButtonMenuItem r7=new JRadioButtonMenuItem("blue");
        r7.setForeground(Color.blue);
        r7.addActionListener(e -> text.setForeground(Color.blue));
        menu6.add(r1);menu6.add(r2);menu6.add(r3);menu6.add(r4);menu6.add(r5);menu6.add(r6);menu6.add(r7);
        ButtonGroup gr=new ButtonGroup();
        gr.add(r1);gr.add(r2);gr.add(r3);gr.add(r4);gr.add(r5);gr.add(r6);gr.add(r7);

        JMenu menu7=new JMenu("Background");
        JRadioButtonMenuItem a1=new JRadioButtonMenuItem("green");
        a1.setForeground(Color.green);
        a1.addActionListener(e -> text.setBackground(Color.green));
        JRadioButtonMenuItem a2=new JRadioButtonMenuItem("orange");
        a2.setForeground(Color.orange);
        a2.addActionListener(e -> text.setBackground(Color.orange));
        JRadioButtonMenuItem a3=new JRadioButtonMenuItem("red");
        a3.setForeground(Color.red);
        a3.addActionListener(e -> text.setBackground(Color.red));
        JRadioButtonMenuItem a4=new JRadioButtonMenuItem("black");
        a4.setForeground(Color.black);
        a4.addActionListener(e -> text.setBackground(Color.black));
        JRadioButtonMenuItem a5=new JRadioButtonMenuItem("white");
        a5.setForeground(Color.white);
        a5.addActionListener(e -> text.setBackground(Color.white));
        JRadioButtonMenuItem a6=new JRadioButtonMenuItem("yellow");
        a6.setForeground(Color.yellow);
        a6.addActionListener(e -> text.setBackground(Color.yellow));
        JRadioButtonMenuItem a7=new JRadioButtonMenuItem("blue");
        a7.setForeground(Color.blue);
        a7.addActionListener(e -> text.setBackground(Color.blue));
        menu7.add(a1);menu7.add(a2);menu7.add(a3);menu7.add(a4);menu7.add(a5);menu7.add(a6);menu7.add(a7);
        menu3.add(menu7);
        JMenu menu8=new JMenu("Font size");
        JMenuItem fs1 = new JMenuItem("8 pts");
        fs1.setFont(fs1.getFont().deriveFont(8.0f));
        fs1.addActionListener(e -> text.setFont(fs1.getFont().deriveFont(8.0f)));
        JMenuItem fs2 = new JMenuItem("10 pts");
        fs2.setFont(fs2.getFont().deriveFont(10.0f));
        fs2.addActionListener(e -> text.setFont(fs2.getFont().deriveFont(10.0f)));
        JMenuItem fs3 = new JMenuItem("12 pts");
        fs3.setFont(fs3.getFont().deriveFont(12.0f));
        fs3.addActionListener(e -> text.setFont(fs3.getFont().deriveFont(12.0f)));
        JMenuItem fs4 = new JMenuItem("14 pts");
        fs4.setFont(fs4.getFont().deriveFont(14.0f));
        fs4.addActionListener(e -> text.setFont(fs4.getFont().deriveFont(14.0f)));
        JMenuItem fs5 = new JMenuItem("16 pts");
        fs5.setFont(fs5.getFont().deriveFont(16.0f));
        fs5.addActionListener(e -> text.setFont(fs5.getFont().deriveFont(16.0f)));
        JMenuItem fs6 = new JMenuItem("18 pts");
        fs6.setFont(fs1.getFont().deriveFont(18.0f));
        fs6.addActionListener(e -> text.setFont(fs6.getFont().deriveFont(18.0f)));
        JMenuItem fs7 = new JMenuItem("20 pts");
        fs7.setFont(fs7.getFont().deriveFont(20.0f));
        fs7.addActionListener(e -> text.setFont(fs7.getFont().deriveFont(20.0f)));
        JMenuItem fs8 = new JMenuItem("22 pts");
        fs8.setFont(fs8.getFont().deriveFont(22.0f));
        fs8.addActionListener(e -> text.setFont(fs8.getFont().deriveFont(22.0f)));
        JMenuItem fs9 = new JMenuItem("24 pts");
        fs9.setFont(fs9.getFont().deriveFont(24.0f));
        fs9.addActionListener(e -> text.setFont(fs9.getFont().deriveFont(24.0f)));
        menu8.add(fs1);menu8.add(fs2);menu8.add(fs3);menu8.add(fs4);menu8.add(fs5);menu8.add(fs6);menu8.add(fs7);menu8.add(fs8);menu8.add(fs9);
        menu3.add(menu8);
        panel=new JPanel();
        frame.add(panel, BorderLayout.PAGE_END);

        Icon circle=new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Color old=g.getColor();
                g.setColor(old);
                g.fillOval(10,10,10,10);

            }

            @Override
            public int getIconWidth() {
                return 10;
            }

            @Override
            public int getIconHeight() {
                return 10;
            }
        };



    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object z= e.getSource();
        if (z==item1){
            JFileChooser fc=new JFileChooser();
            if(fc.showOpenDialog(null)==JFileChooser.APPROVE_OPTION){
                File plik = fc.getSelectedFile();

            }

        }
        else if (z==item2){
            File plik;
            JFileChooser fc=new JFileChooser();
                try {

                     plik=fc.getSelectedFile().getAbsoluteFile();

                }
                catch(NullPointerException a) {
                    if(fc.showSaveDialog(null)==JFileChooser.APPROVE_OPTION){
                        plik = fc.getSelectedFile();
                }
            }

        }
        else if (z==item3){
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Specify a file to save");

            int userSelection = fileChooser.showSaveDialog(frame);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                System.out.println("Save as file: " + fileToSave.getAbsolutePath());
            }
        }
        else if (z==item4){
            System.exit(0);

            }

    }


}
