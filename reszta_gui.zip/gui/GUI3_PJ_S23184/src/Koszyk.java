import java.util.ArrayList;

public class Koszyk extends Cennik {
    int wzrost=0;
    private ArrayList<Object> lista = new ArrayList<Object>();
    Koszyk(Klient ab ){
        this.lista=ab.list;


    }

    public ArrayList<Object> getLista() {
        return lista;
    }

    public void print(){
        for (Object el: lista)
            if (el != null)
                System.out.println(el);
        System.out.println();
    }
}
