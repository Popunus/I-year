import java.util.ArrayList;

public class Klient <T > {
    private String imie;
    private int budzet;
    int size;
    Object[] arr;
    ArrayList<Object> listapoprzepakowaniu = new ArrayList<Object>();
    Klient(){

    }




    public  ListaZakupow pobierzListeZakupow() {

        return ListaZakupow;
    }

    ArrayList<Object> list = new ArrayList<Object>();
    public ArrayList<Object> getArray() {
        return this.list;
    }
    public void dodaj(T el)
    {
        list.add(el);
    }


    public Klient(String a, int b){
        this.imie=a;
        this.budzet=b;
    }
    public void print(){
        for (Object el: list)
            if (el != null)
                System.out.println(el);
        System.out.println();
    }

    public ArrayList<Object> przepakuj(Koszyk obiekt){
        listapoprzepakowaniu=obiekt.getLista();
        return listapoprzepakowaniu;
    }

    public int pobierzPortfel() {
        return budzet;
    }
}

