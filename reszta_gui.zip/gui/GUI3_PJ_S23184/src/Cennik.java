import java.util.ArrayList;
public class Cennik extends ArrayList<T> {
    String kolor;
    String smak;
    int cena;
    int iloscprzyznizce;
    int cenazeznizka;
    boolean ktore;
    int wartosc=0;
    String [] []arr=new String[4][5];

    private static Cennik instance = null;

    public static Cennik pobierzCennik() {
        if (instance == null) {
            instance = new Cennik();
        }
        return instance;
    }


    // retrieve array from anywhere

    //Add element to array
    public void dodaj(String a, String b, int c) {
        kolor=a;
        smak=b;
        cena=c;
        arr[wartosc][0]=a;
        arr[wartosc][1]=b;
        arr[wartosc][2]=String.valueOf(c);
        wartosc++;

        ktore=true;

    }
    public void dodaj(String a, String b, int c,int d,int e) {
        kolor=a;
        smak=b;
        iloscprzyznizce=c;
        cenazeznizka=d;
        cena=e;
        arr[wartosc][0]=a;
        arr[wartosc][1]=b;
        arr[wartosc][2]=String.valueOf(c);
        arr[wartosc][3]=String.valueOf(d);
        arr[wartosc][4]=String.valueOf(e);
        ktore=false;
        wartosc++;
    }

    public String toString(){
        if(ktore==false)
        return kolor+" "+smak+" "+iloscprzyznizce+" "+cenazeznizka+" "+cena;
        else
            return kolor+" "+smak+" "+cena;
    }
    void print(){
        for(int i=0;i< arr.length;i++){
            for(int j=0;j<arr[i].length;j++){
                System.out.print(arr[i][j]);
            }
            System.out.println();
        }
    }

}