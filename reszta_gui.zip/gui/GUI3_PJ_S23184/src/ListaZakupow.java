import java.util.ArrayList;
import java.util.*;
public class ListaZakupow extends Klient
{


    public String toString(){
        return super.toString();

    }

}