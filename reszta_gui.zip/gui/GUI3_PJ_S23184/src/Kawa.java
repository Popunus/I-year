
class Zielona {
    String nazwa;
    int ilosc;

    public Zielona(String a,int b) {
        this.nazwa=a;
        this.ilosc=b;
    }
    public String toString(){
        return "zielona"+" "+nazwa+" "+ilosc;
    }
}
class Czerwona  {
    String nazwa;
    int ilosc;


    public Czerwona(String a,int b) {
        this.nazwa=a;
        this.ilosc=b;
    }
    public String toString(){
        return"czerwona"+" "+nazwa+" "+ilosc;
    }
}
class Czarna  {
    String nazwa;
    int ilosc;

    public Czarna(String a,int b) {
        this.nazwa=a;
        this.ilosc=b;
    }
    public String toString(){
        return "czarna"+" "+nazwa+" "+ilosc;
    }
}
class Niebieska  {
    String nazwa;
    int ilosc;

    public Niebieska(String a,int b) {
        this.nazwa=a;
        this.ilosc=b;
    }
    public String toString(){
        return "niebieska"+" "+nazwa+" "+ilosc;
    }
    }


