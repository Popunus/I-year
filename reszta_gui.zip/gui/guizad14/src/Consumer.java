class Consumer implements Runnable {

    private Buffer buff;
    private int liczba;
    // konstruktor
    public Consumer(Buffer b) {
        buff=b;
        this.liczba=liczba;
    }

    @Override
    public void run() {
        while (true) {
            try {
                buff.get();
            } catch (InterruptedException e) {

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException a) {
                    a.printStackTrace();
                }
                notify();
            }


        }

        // ...
    }

    // ...
}