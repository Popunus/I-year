public class Test {
    public static void main(String[] args) {

        // ...

        Buffer buffer = new Buffer(10);
        Producer producer = new Producer(buffer);
        Consumer consumer = new Consumer(buffer);

        // utworzenie i uruchomienie wątków producenta i konsumenta
        // ...
        Thread watekproducent = new Thread(producer);
        Thread watekkonsument = new Thread(consumer);
        watekproducent.start();
        watekkonsument.start();
        try {
            Thread.sleep(15000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            watekproducent.interrupt();
            watekkonsument.interrupt();
        }

        // ...
    }
}