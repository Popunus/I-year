class Producer implements Runnable {

    private Buffer buff;
    int liczba;

    // konstruktor
    public Producer(Buffer b) {
        this.liczba = (int)(Math.random()*100);


    }

    @Override
    public void run() {
        while (true) {
            try {
                buff.put(liczba);
            } catch (InterruptedException e) {

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException a) {
                    a.printStackTrace();
                }
                notify();
            }


        }

        // ...
    }
}
