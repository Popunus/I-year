class Buffer {
    int size;
    int temp=0;
    ;
    private int[] arr;

    // konstruktor
    public Buffer(int size) {
        this.arr = new int[size];
    }


    //...

    public void put(int n) throws InterruptedException {

        synchronized (this) {
            while (size>0) {
                wait();
            }
            notify();
            arr[temp] = n;
            size--;
            temp++;

        }
    }


    public synchronized int get() throws InterruptedException {

        synchronized (this) {
            while (size == 0) {
                wait();
            }
            notify();

            return arr[temp];
        }
    }
}