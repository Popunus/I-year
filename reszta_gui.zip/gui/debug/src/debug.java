public class debug {
    public static void main(String[] args) {
       /* int i = 0;
        int j = 5;
        if (i < j) {
            for (int k = i + 2; k <= j; k++) {
                System.out.print("*");}
        } else {for (int k = j; k > i; k--) {
            System.out.print("$");
        }}*/
        //wedlug mnie wyswietli sie
        //****
        //mialem racje

        int x = -1;
        for (int i = 0; i < 10; i++) {
            if (++x != 10) {
                for (int j = i % 2; j != 5; j++) {
                    x -= 2;
                }}
            if (++x < 10) {
                continue;}}
        //x bedzie rowne -37

        /*int[] array = {1, 2, 3, 3, 2, 1};
        boolean palindrome = true;
        // start
        for (int i = 0, j = array.length-1 ; i != j ; i++, j--) {
            if(i>array.length-1 || j<0)
                break;
            if (array[i] != array[j]  ) {
                palindrome = false;
            break;
            }
        }*/
        // stop
        //System.out.println(palindrome ? "Palindrome" : "Not a palindrome");
        //za problem odpowiada parzysta tablica co powodowalo array out of bounds exception
    }

}
