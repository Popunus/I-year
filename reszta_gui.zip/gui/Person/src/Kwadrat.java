public class Kwadrat {
    private int bok;
    public Kwadrat(int temp_side){
        this.bok=temp_side;
    }

    public void show(){
        System.out.println("pole kwadratu: "+bok*bok);
        System.out.println("objetosc szescianu : "+bok*bok*bok);
    }

    public static void main(String[] args) {
        Kwadrat dziad=new Kwadrat(6);
        dziad.show();
    }
}
