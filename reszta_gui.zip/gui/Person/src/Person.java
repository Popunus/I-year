public class Person {
    public String name;
    public String surname;
    public int birthyear;
    public static void main(String[] args){
        Person person =new Person();
        person.name="kaz";
        person.surname="rom";
        person.birthyear=2001;

    }
}
