public class Dzem {
    String smak;
    double waga;
    public Dzem(String smak, double waga){
        this.smak=smak;
        this.waga=waga;
    }
    public Dzem( double waga){
        this.smak="No name";
        this.waga=waga;
    }
    public Dzem(String smak){
        this.smak=smak;
        this.waga=100.0;
    }
    public void show(){
        System.out.println(this.smak);
        System.out.println(this.waga);
    }

    public static void main(String[] args) {
        Dzem one=new Dzem("kokos",100.1);
        Dzem two=new Dzem("czoko");
        Dzem three=new Dzem(85.5);
        one.show();
        two.show();
        three.show();
    }
}
