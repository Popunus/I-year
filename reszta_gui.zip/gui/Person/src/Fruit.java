public class Fruit {
    String name;
    double weight;
     Fruit(String namee){
         this.name= namee;
        this.weight=Math.random()*0.3+0.5;
    }
    public void show(){
        System.out.println("name: " + this.name);
        System.out.println("weight: " + this.weight);
    }


    public static void main(String[] args) {

        Fruit smoczy=new Fruit("smok");
        smoczy.show();
    }

}
