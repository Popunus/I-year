public class Sloik {
    Dzem dzem;

}
