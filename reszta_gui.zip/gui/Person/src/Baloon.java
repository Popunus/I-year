public class Baloon {
    String name;
    double how_much_helium;
    Baloon(String nametemp){
        this.name=nametemp;
        how_much_helium=Math.random()*0.004+0.005;
    }
    public void getLoad(){
        double temp_helium=how_much_helium*1000;
        double result=(temp_helium*86)/10;

        System.out.println(how_much_helium+"this is the capacity of "+name+"= "+result);
    }

    public static void main(String[] args) {
        Baloon dziad=new Baloon("elooo");
        dziad.getLoad();
    }
}
