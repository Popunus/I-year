public class KulaW {
    private double promien;
    private double promienK;
    private double wysokosc;
    private double side;

    public KulaW(int temp_promien, int temp_wysokosc) {
        this.promien = temp_promien;
        this.wysokosc = temp_wysokosc;
    }

    public KulaW(double temp_side) {
        this.side = temp_side;
    }

    public void show() {
        if (side != 0) {
            double result = side * side * side;
            double objkuli = 0;
            double zmienna = 1;
            while (result > objkuli) {
                objkuli = 4 / 3 * Math.PI * Math.pow(zmienna, 3);
                zmienna++;
            }
            System.out.println("objetosc kuli w szescianie= "+objkuli+"a promien wynosi"+zmienna);
            System.out.println("objestosc szescianu wynosi="+result);
        }
        if (wysokosc != 0 && promien != 0){
            double result = Math.PI*Math.pow(promien,2)*wysokosc;
            double objkuli = 0;
            double zmienna = 1;
            while (result > objkuli) {
                objkuli = 4 / 3 * Math.PI * Math.pow(zmienna, 3);
                zmienna++;
            }
            System.out.println("objetosc kuli w walcu= "+objkuli+"a promien wynosi "+zmienna);
            System.out.println("objestosc walca wynosi="+result);
        }
        }

    public static void main(String[] args) {
        KulaW dajefula=new KulaW(5,2);
        dajefula.show();
    }
    }

