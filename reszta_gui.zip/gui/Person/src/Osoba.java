public class Osoba {
    String imie;
    int rokUrodzenia;
    public Osoba(String temp_name, int temp_birthyear){
        this.imie=temp_name;
        this.rokUrodzenia=temp_birthyear;
    }
    public Osoba(String temp_name){
        this.imie=temp_name;
        this.rokUrodzenia=1990;
    }
    public String  zwrocImie(){
        return this.imie;
    }
    public int  zwrocWiek(){
        return this.rokUrodzenia;
    }
    public static int zwrocStarszaOsobe(Osoba a,Osoba b){
        if(a.rokUrodzenia<b.rokUrodzenia)
            return a.rokUrodzenia;
        else
            return b.rokUrodzenia;

    }
    public static int zwrocNajstarszaOsobe(Osoba [] arr){
        int oldest=arr[0].rokUrodzenia;
        for(int i=0;i<arr.length;i++){
            if(oldest>arr[i].rokUrodzenia)
                oldest=arr[i].rokUrodzenia;
        }
        return oldest;
    }

    public static void main(String[] args) {
        Osoba a=new Osoba("elo1",2001);
        Osoba b=new Osoba("elo2",2122);
        Osoba c=new Osoba("elo3",2010);
        Osoba d=new Osoba("eloo4");
        Osoba [] arr={a,b,c,d};
        System.out.println(Osoba.zwrocNajstarszaOsobe(arr));
        System.out.println();
    }
}
