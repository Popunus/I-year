public class Walec {
    private double promien;
    private double wysokosc;
    public Walec(int temp_promien,int temp_wysokosc){
        this.promien=temp_promien;
        this.wysokosc=temp_wysokosc;
    }
    public void show(){
        System.out.println("pole powierzchni calkowitej: "+2*Math.PI*promien*(promien+wysokosc));
        System.out.println("objetosc walca : "+(Math.PI*Math.pow(promien,2)*wysokosc));
    }

    public static void main(String[] args) {
        Walec elo=new Walec(5,10);
        elo.show();
    }
}
