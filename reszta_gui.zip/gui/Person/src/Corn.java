public class Corn {
    int cornCount;
    public Corn(int tempCount){
        this.cornCount=tempCount;
    }
    public Corn [] arr(){
        for(int i=0;i<cornCount;i++){
            arr[i]=this;
        }
    }
}
