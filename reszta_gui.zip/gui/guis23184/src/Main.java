public class Main {

    public static void main(String[] args) {
        Flyable sokol = new Bird();
        sokol.drive();
        sokol.distance();
        Speakable sokols = new Bird();
        sokols.speak();

        Flyable mitsubishizero = new Plane();
        mitsubishizero.drive();
        mitsubishizero.distance();
        Speakable mitsubishizeros = new Plane();
        mitsubishizeros.speak();

        Flyable area51 = new UFO();
        area51.drive();
        area51.distance();
        Speakable area51s = new UFO();
        area51s.speak();

        Flyable korona = new Virus();
        korona.drive();
        korona.distance();
        Speakable koronas = new Virus();
        koronas.speak();

        Flyable  a[]={korona,sokol,area51,mitsubishizero};
        for (Flyable s : a)
            System.out.println(s);

        System.out.println("\n"+ "najkrotszy:"+ Flyable.najkrotszy(a));
        Speakable b[]={koronas,sokols,area51s,mitsubishizeros};
    }

}
interface Flyable {
    public String drive();


    public double distance();

    public static Flyable najkrotszy(Flyable[] tablica){
        double najk=tablica[0].distance();
        Flyable kto=tablica[0];

        for(Flyable obecny:tablica){
            if(najk>obecny.distance()){
                najk=obecny.distance();
                kto=obecny;
            }


        }
        return kto;
    }

}

interface Speakable {


    public String speak();


}

class Plane implements Flyable, Speakable {


    @Override
    public String drive() {
        return "silnik";
    }

    @Override
    public double distance() {
        return 100;
    }

    @Override
    public String speak() {
        return "siuuuu";
    }
    public String toString() {
        return getClass().getName()+" "+drive()+" "+distance()+" "+ speak();
    }

}

class UFO implements Flyable, Speakable {


    @Override
    public String drive() {
        return "napęd nieznany";
    }

    @Override
    public double distance() {
        return 10000;
    }

    @Override
    public String speak() {
        return "????????";
    }
    public String toString() {
        return getClass().getName()+" "+drive()+" "+distance()+" "+ speak();
    }
}

class Virus implements Flyable, Speakable {


    @Override
    public String drive() {
        return "brak";
    }

    @Override
    public double distance() {
        return 1;
    }

    @Override
    public String speak() {
        return null;
    }
    public String toString() {
        return getClass().getName()+" "+drive()+" "+distance()+" "+ speak();
    }
}

class Bird implements Flyable, Speakable {


    @Override
    public String drive() {
        return "skrzydlo";
    }

    @Override
    public double distance() {
        return 10;
    }

    @Override
    public String speak() {
        return "cwircwir";
    }

    public String toString() {
        return getClass().getName()+" "+drive()+" "+distance()+" "+ speak();
    }


}
