import java.util.ArrayList;
import java.util.Arrays;

public class ListaZyczen  {
    ArrayList< Pokoje > lista_cel = new ArrayList<>();



    @Override
    public String toString() {
        return Arrays.asList(lista_cel).toString();
    }
}
