
public abstract class Pokoje {
    public String typ;
    public int ile_nocy;
    public boolean czy_sniadanie;
    public Pokoje(String typ,int ile_nocy,boolean czy_sniadanie){
        this.typ=typ;
        this.ile_nocy=ile_nocy;
        this.czy_sniadanie=czy_sniadanie;
    }

    @Override
    public String toString() {
        return getClas()+"{" +
                "typ='" + typ + '\'' +
                ", ile_nocy=" + ile_nocy +
                ", czy_sniadanie=" + czy_sniadanie +
                '}';
    }

    public String getClas() {
        return "pokoje";
    }

    public String getTyp() {
        return typ;
    }

    public int getIle_nocy() {
        return ile_nocy;
    }
}
class Jedynka extends Pokoje {
    public Jedynka(String typ,int ile_nocy,boolean czy_sniadanie){
        super(typ,ile_nocy,czy_sniadanie);
    }

    @Override
    public String toString() {
        return getClas()+"{" +
                "typ='" + typ + '\'' +
                ", ile_nocy=" + ile_nocy +
                ", czy_sniadanie=" + czy_sniadanie +
                '}';
    }
    @Override
    public String getClas(){
        return "jedynka";
    }
    @Override
    public String getTyp() {
        return typ;
    }

    @Override
    public int getIle_nocy() {
        return super.getIle_nocy();
    }
}
class Trojka extends Pokoje {
    public Trojka(String typ,int ile_nocy,boolean czy_sniadanie){
        super(typ,ile_nocy,czy_sniadanie);
    }
    @Override
    public String toString() {
        {
            return getClas()+"{" +
                    "typ='" + typ + '\'' +
                    ", ile_nocy=" + ile_nocy +
                    ", czy_sniadanie=" + czy_sniadanie +
                    '}';
        }
    }
    @Override
    public String getClas(){
        return "trojka";
    }
    @Override
    public String getTyp() {
        return typ;
    }

    @Override
    public int getIle_nocy() {
        return super.getIle_nocy();
    }
}
class Dwojka extends Pokoje {
    public Dwojka(String typ,int ile_nocy,boolean czy_sniadanie){
        super(typ,ile_nocy,czy_sniadanie);
    }
    @Override
    public String toString() {
        {
            return getClass()+"{" +
                    "typ='" + typ + '\'' +
                    ", ile_nocy=" + ile_nocy +
                    ", czy_sniadanie=" + czy_sniadanie +
                    '}';
        }
    }
    @Override
    public String getClas(){
        return "dwojka";
    }
    @Override
    public String getTyp() {
        return typ;
    }

    @Override
    public int getIle_nocy() {
        return super.getIle_nocy();
    }
}
class Rodzina extends Pokoje {
    public Rodzina(String typ,int ile_nocy,boolean czy_sniadanie){
        super(typ,ile_nocy,czy_sniadanie);
    }
    @Override
    public String toString() {
        {
            return getClass()+"{" +
                    "typ='" + typ + '\'' +
                    ", ile_nocy=" + ile_nocy +
                    ", czy_sniadanie=" + czy_sniadanie +
                    '}';
        }
    }
    @Override
    public String getClas(){
        return "rodzina";
    }
    @Override
    public String getTyp() {
        return typ;
    }

    @Override
    public int getIle_nocy() {
        return super.getIle_nocy();
    }
}
