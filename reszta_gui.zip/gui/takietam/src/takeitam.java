public class takeitam {
}
