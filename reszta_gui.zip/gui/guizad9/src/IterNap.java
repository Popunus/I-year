import java.util.Iterator;

public class IterNap implements Iterable<Character> {


    private int koniec;
    private String zdanie;
    private int krok;
    private int start;

    public IterNap(String zdanie) {
        this.start = 0;
        this.koniec = zdanie.length();
        this.zdanie = zdanie;
        this.krok = 1;
    }



    public void ustawPoczatek(int start) {
        this.start = start;
    }

    public void ustawKrok(int krok) {
        this.krok = krok;
    }


    public Iterator<Character> iterator() {

        return new Iterator<Character>() {

            int obecny = start;


            public boolean hasNext() {
                return obecny < koniec;
            }


            public Character next() {
                Character obecnyznak= zdanie.charAt(obecny);
                obecny += krok;
                return obecnyznak;
            }




        };
    }
}