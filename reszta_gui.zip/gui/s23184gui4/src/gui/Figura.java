
abstract class Figura implements Comparable<Figura>{

    private int x, y;
    private int numer, obecnynumer;

    // konstruktor
    public Figura(int x, int y)
    {
        this.x=x;
        this.y=y;
        obecnynumer=numer;
        numer++;
    }

    // metody abstrakcyjne
    public abstract String fig();
    public abstract void pozycja(int x, int y);
    public abstract int pole();
    public abstract int obw();

    @Override
    public String toString()
    {
        return fig();
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

// ...

    @Override
    public int compareTo(Figura f)
    {
        // obiekty: this, f
        // obiekt1.compareTo(obiekt2)

        if (this.pole() - f.pole() < 0)
            return -1;	// < 0
        else if (this.pole() - f.pole() > 0)
            return 1; 	// > 0
        else if (this.obw() - f.obw() < 0)
            return -1;	// < 0
        else if (this.obw() - f.obw() > 0)
            return 1;
        else if (this.obecnynumer - f.obecnynumer < 0)
            return -1;	// < 0
        else if (this.obecnynumer - f.obecnynumer > 0)
            return 1;
        else
            return 0;
    }


    // ...
}


class Kolo extends Figura {

    private int promien;

    // konstruktor
    public Kolo(int x, int y, int r)
    {
        super(x,y);
        promien=r;

    }

    @Override
    public String fig() {
        return "Koło";
    }
    @Override
    public int pole()
    {
        int r=promien;
        return ((int)(Math.PI*(Math.pow(r,2))));
    }
    @Override
    public int obw()
    {
        int r=promien;
        return ((int)(2*Math.PI*r));
    }
    @Override
    public void pozycja(int x, int y)
    {
        double b=2;
        int odleglosc=(int)Math.sqrt((int)Math.pow((((double)((x-getX())))+((double)(y-getY()))), b));

        if(odleglosc<=promien) {
            System.out.println("Punkt("+x+","+y+")"+"znajduje sie wewnatrz kola");
        }
        if(odleglosc>promien){
            System.out.println("Punkt("+x+","+y+")"+"znajduje sie na zewnatrz kola");
        }
    }

    @Override
    public String toString()
    {
        return super.toString()+"\nSrodek -("+getX()+","+getY()+")"+"\nPromien -"+promien;
    }


    //...
}

class Prostokat extends Figura  {

    protected int szer, wys;

    // konstruktor
    public Prostokat(int x, int y, int s, int w)
    {
        super(x,y);
        szer=s;
        wys=w;

    }



    @Override
    public String fig() {
        return "Prostokat";
    }

    @Override
    public void pozycja(int x, int y)
    {
        boolean a=false;
        boolean b=false;
        if(x>getX()-wys&&x<getX()){
            a=true;
        }
        if(y>getY()-szer&&y<getY()){
            b=true;
        }
        if(a && b && a && b){
            System.out.println("Punkt("+x+","+y+")"+"znajduje sie  wewnatrz prostokata");
        }
        else
            System.out.println("Punkt("+x+","+y+")"+"znajduje sie na zewnatrz prostokata");
    }
    @Override
    public int pole()
    {
        int a=szer;
        int b=wys;
        return a*b;
    }
    @Override
    public int obw()
    {
        int a=wys;
        int b=szer;
        return 2*(wys+szer);
    }

    @Override
    public String toString()
    {
        return super.toString() + "\nLewy górny - (" + getX() + ',' + getY() + ")" + "\nSzerokość: " + szer + ", " + "Wysokość: " + wys + "\n";
    }

}





