import java.util.List;
import java.util.*;
import java.util.Arrays;
package gui;
class TestFigur {



    public static void main(String[] args) {

        // lista figur
        // https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html
        List<Figura> listaFig = new ArrayList<Figura>();
        Figura p1=new Prostokat(1,1,4,9);
        listaFig.add(p1);
        Figura p2=new Kolo(2,2,5);
        listaFig.add(p2);
        Figura p3=new Prostokat(2,2,6,6);
        listaFig.add(p3);


        System.out.println("Figury przed sortowaniem:");

        for (Figura a: listaFig) {
            System.out.println(a);
            System.out.println();
        }

            // sortowanie listy figur
            Collections.sort(listaFig);


        System.out.println("Figury po sortowaniu:");

        for (Figura f: listaFig) {
            System.out.println(f);
            System.out.println();
        }


    }
}

