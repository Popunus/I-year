public class TestGame {

    public static void main(String[] args)
    {
        Player p1 = new Player("ppj");                                            // tworzenie gracza ze swoim identyfikatorem
        Player p2 = new Player("gui");

        Referee ref = new Referee(10, new Player[]{p1,p2});                       // arbiter ustala czas gry (w sekundach), "rejestruje" tablicę graczy

        ref.startGame();                                                          // arbiter startuje swój wątek: mierzy czas oraz daje sygnał startu graczom

        try {
            ref.join();                                                           // czekamy, aż wątek arbitra zakończy swoją pracę, tzn. po upływie określonego czasu przerywa pracę wątków wszystkich graczy

            // join() jest metodą z klasy Thread

        } catch (InterruptedException exc){

            exc.printStackTrace();

        }

        ref.result();                                                              // arbiter ogłasza wynik gry

    }
}

class Player extends Thread {

    private int suma=0;

    public Player(String nazwa)
    {
        super(nazwa);

    }
    // praca wątku gracza
    public void run()
    {


        while (true) {

                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    return;
                }

                // opóźnienie czasowe (losowe)
                //...

                double randNumber = Math.random();
                double d = randNumber * 100;
                int liczba = (int) d;

                System.out.println(getName() + ": " + liczba);
                // losowanie liczby
                //...

                this.suma += liczba;




        }
    }




    int getSuma(){
        return suma;
    }

    //...

}


class Referee extends Thread {


    private int time;
    Player[] a;

    public Referee(int time, Player[] pl)
    {
        this.time=time;
        this.a=pl;
    }

    void startGame(){

        // start wątku arbitra
        this.start();

        a[0].start();
        a[1].start();


    }

    // praca wątku arbitra
    public void run()
    {
        while(time>0){


            System.out.println("czas "+time);
            try{
                Thread.sleep(1000);




            }
            catch (InterruptedException e){
                return;
            }
            time--;


        }
        a[0].interrupt();
        a[1].interrupt();

        // mierzenie czasu
        //...

        // przerywanie pracy wątków-graczy
        //...
    }

    void result()
    {
        System.out.println("wyniki ppj:"+" "+a[0].getSuma());
        System.out.println("wyniki gui:"+" "+a[1].getSuma());
        if(a[0].getSuma()>a[1].getSuma())
            System.out.println(a[0].getName()+" "+"wygral!");
        if(a[0].getSuma()<a[1].getSuma())
            System.out.println(a[1].getName()+" "+"wygral!");

    }

}