public class AbstractListModel{
    AbstractListModel styczen=new AbstractListModel(){
        public Object getElementAt(int i){return(i+1)+" stycznia";}
        int getSize(){return 31;}
    };

}