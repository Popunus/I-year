import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.io.File;

public class Main {
        public static void main(String[] args) {
            EventQueue.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Main();
                }
            });
    }


     public  Main(){

         JFrame frame = new JFrame("Simple Swing App");
         JPanel panel = new JPanel();
         JPanel panel2 = new JPanel();
         frame.getContentPane();
         JButton button1 = new JButton("1");
         JButton button2 = new JButton("2");
         JButton button3 = new JButton("3");
         JButton button4 = new JButton("4");
         JButton button5 = new JButton("5");
         JButton button6 = new JButton("6");
         JButton button7 = new JButton("7");
         JButton button8 = new JButton("8");
         JButton button9 = new JButton("9");

         button1.setBounds(10, 255, 40, 30);
         button2.setBounds(55, 255, 40, 30);
         button3.setBounds(100, 255, 40, 30);
         button4.setBounds(10, 290, 40, 30);
         button5.setBounds(55, 290, 40, 30);
         button6.setBounds(100, 290, 40, 30);
         button7.setBounds(10, 325, 40, 30);
         button8.setBounds(55, 325, 40, 30);
         button9.setBounds(100, 325, 40, 30);

         panel.setLayout(null);
         panel.add(button1);
         panel.add(button2);
         panel.add(button3);
         panel.add(button4);
         panel.add(button5);
         panel.add(button6);
         panel.add(button7);
         panel.add(button8);
         panel.add(button9);

         JButton button10 = new JButton("FR");
         button10.setBackground(Color.RED);
         JButton button11 = new JButton("FG");
         button11.setBackground(Color.GREEN);
         JButton button12 = new JButton("FB");
         button12.setBackground(Color.BLUE);

         JButton button13 = new JButton("A");
         JButton button14 = new JButton("B");
         JButton button15= new JButton("C");

         button10.setBounds(10, 10, 50, 35);
         button11.setBounds(65, 10, 51, 35);
         button12.setBounds(120, 10, 50, 35);
         button13.setBounds(420, 10, 50, 35);
         button14.setBounds(475, 10, 50, 35);
         button15.setBounds(530, 10, 50, 35);

         panel.add(button10);
         panel.add(button11);
         panel.add(button12);
         panel.add(button13);
         panel.add(button14);
         panel.add(button15);


         JTextField text1=new JTextField("Pole tekstowe 1 typu JTextField");
         text1.setBounds(new Rectangle(350, 260, 230, 35));
         text1.setBorder(new LineBorder(Color.CYAN,1));
         JTextField text2=new JTextField("Pole tekstowe 2 typu JTextField");
         text2.setBounds(new Rectangle(350, 295, 230, 35));
         text2.setBorder(new LineBorder(Color.CYAN,1));
         JTextField text3=new JTextField("Pole tekstowe 3 typu JTextField");
         text3.setBounds(new Rectangle(350, 330, 230, 35));
         text3.setBorder(new LineBorder(Color.CYAN,1));

         panel.add(text1);
         panel.add(text2);
         panel.add(text3);

         JTextArea area=new JTextArea("Obszar tekstowy typu JTextArea");
         area.setBounds(new Rectangle(0, 50, 600, 200));

         button10.addActionListener(e -> area.setForeground(Color.red));
         button11.addActionListener(e -> area.setForeground(Color.GREEN));
         button12.addActionListener(e -> area.setForeground(Color.BLUE));




         JScrollPane scrollPane = new JScrollPane(panel);
         frame.add(scrollPane);

         panel.add(area);

            text1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    area.append("\n"+text1.getText());
                }
            });

         text2.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {

                 area.append("\n"+text1.getText());
             }
         });


         text3.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {

                 area.append("\n"+text1.getText());
             }
         });


         frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
         frame.add(panel);
         frame.setSize(600, 400);
         frame.setVisible(true);


        }


}
