import javax.swing.*;
import java.awt.*;
import javax.swing.JOptionPane;

public class Test {
    public static void main(String[] args) {

        new Test();
    }



    public Test(){
        String data;
        data= JOptionPane.showInputDialog("Hi you can choose layout by writing capital letters from A-G");
        JButton btn1= new JButton("Przycisk 1");
        JButton btn2= new JButton("P 2");
        JButton btn3= new JButton("Większy przycisk numer 3");
        JButton btn4= new JButton("Przycisk 4");
        JButton btn5= new JButton("P5");
        JFrame frame = new JFrame("Layout");
        switch (data) {
            case "A": {
                frame.setLayout(new BorderLayout());
                frame.add(btn1, BorderLayout.NORTH);
                frame.add(btn2, BorderLayout.SOUTH);
                frame.add(btn3, BorderLayout.CENTER);
                frame.add(btn4, BorderLayout.WEST);
                frame.add(btn5, BorderLayout.EAST);
            }
            break;
            case "B": {
                frame.setLayout(new FlowLayout(FlowLayout.CENTER));
                frame.add(btn1);
                frame.add(btn2);
                frame.add(btn3);
                frame.add(btn4);
                frame.add(btn5);
            }
            break;
            case "C": {
                frame.setLayout(new FlowLayout(FlowLayout.LEFT));
                frame.add(btn1);
                frame.add(btn2);
                frame.add(btn3);
                frame.add(btn4);
                frame.add(btn5);
            }
            break;
            case "D": {
                frame.setLayout(new FlowLayout(FlowLayout.RIGHT));
                frame.add(btn1);
                frame.add(btn2);
                frame.add(btn3);
                frame.add(btn4);
                frame.add(btn5);
            }
            break;
            case "E": {
                GridLayout gridLayout = new GridLayout();
                gridLayout.setRows(1);
                frame.setLayout(gridLayout);
                frame.add(btn1);
                frame.add(btn2);
                frame.add(btn3);
                frame.add(btn4);
                frame.add(btn5);
            }
            break;
            case "F": {
                GridLayout gridLayout = new GridLayout();
                gridLayout.setColumns(1);
                gridLayout.setRows(5);
                frame.setLayout(gridLayout);
                frame.add(btn1);
                frame.add(btn2);
                frame.add(btn3);
                frame.add(btn4);
                frame.add(btn5);
            }
            break;
            case "G": {
                GridLayout gridLayout = new GridLayout();
                gridLayout.setRows(2);
                gridLayout.setColumns(3);
                frame.setLayout(gridLayout);
                frame.add(btn1);
                frame.add(btn2);
                frame.add(btn3);
                frame.add(btn4);
                frame.add(btn5);
            }
            break;

        }
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }
}
