import java.util.Scanner;
public class main {
    public static void main(String[] args) {

        int tab1[]={1,2,3,4,5};
        int tab2[];
        tab2=tab1;
        System.out.println(tab1.length+", "+ tab2.length);
        /*Scanner scan = new Scanner(System.in);
        boolean wygrana=false;
        char num1='1';
        char num2='2';
        char num3='3';
        char num4='4';
        char num5='5';
        char num6='6';
        char num7='7';
        char num8='8';
        char num9='9';



        System.out.println();
        for(int i=1;i<=9;i++) {

            String ruch = scan.nextLine();
            int ruchint = Integer.parseInt(ruch);
            System.out.println("tura: " + i);
            if (i % 2 == 0) {
                switch (ruchint) {
                    case 1:
                        num1 = '0';
                        break;
                    case 2:
                        num2 = '0';
                        break;
                    case 3:
                        num3 = '0';
                        break;
                    case 4:
                        num4 = '0';
                        break;
                    case 5:
                        num5 = '0';
                        break;
                    case 6:
                        num6 = '0';
                        break;
                    case 7:
                        num7 = '0';
                        break;
                    case 8:
                        num8 = '0';
                        break;
                    case 9:
                        num9 = '0';
                        break;


                }
            } else {
                switch (ruchint) {
                    case 1:
                        num1 = 'x';
                        break;
                    case 2:
                        num2 = 'x';
                        break;
                    case 3:
                        num3 = 'x';
                        break;
                    case 4:
                        num4 = 'x';
                        break;
                    case 5:
                        num5 = 'x';
                        break;
                    case 6:
                        num6 = 'x';
                        break;
                    case 7:
                        num7 = 'x';
                        break;
                    case 8:
                        num8 = 'x';
                        break;
                    case 9:
                        num9 = 'x';
                        break;


                }
            }
            System.out.println(num1 + " " + num2 + " " + num3);
            System.out.println(num4 + " " + num5 + " " + num6);
            System.out.println(num7 + " " + num8 + " " + num9);
            if (num7 == num8 && num8 == num9) {
                System.out.println("gracz z " + num7 + " znakiem wygrywa!");
                wygrana=true;
            }

            if (num4 == num5 && num5 == num6) {
                System.out.println("gracz z " + num5 + " znakiem wygrywa!");
                wygrana=true;
            }
            if (num1 == num2 && num2 == num3) {
                System.out.println("gracz z " + num3 + " znakiem wygrywa!");
                wygrana=true;
            }
            if (num1 == num4 && num4 == num7) {
                System.out.println("gracz z " + num1 + " znakiem wygrywa!");
                wygrana=true;
            }
            if (num2 == num5 && num5 == num8) {
                System.out.println("gracz z " + num2 + " znakiem wygrywa!");
                wygrana=true;
            }
            if (num3 == num6 && num6 == num9) {
                System.out.println("gracz z " + num3 + " znakiem wygrywa!");
                wygrana=true;
            }
            if (num1 == num5 && num5 == num9) {
                System.out.println("gracz z " + num1 + " znakiem wygrywa!");
                wygrana=true;
            }
            if (num7 == num5 && num5 == num3) {
                System.out.println("gracz z " + num3 + " znakiem wygrywa!");
                wygrana=true;
            }
            if(i==9&&wygrana==false){
                System.out.println("remis!");
            }*/


        }
    }

