package gui;

import java.util.Iterator;
import java.util.function.Consumer;

public class IterNap implements Iterable<Character> {
    String napis;
    int krok;
    int start;
    int koniec;
    public IterNap(String napis){
        this.napis=napis;
        this.start=0;
        this.krok=1;
        this.koniec=napis.length();
    }



    public void ustawPoczatek(int poczatek) {
        this.start=poczatek;
    }

    public void ustawKrok(int krok) {
        this.krok=krok;
    }

    @Override
    public Iterator<Character> iterator() {
        return new Iterator<Character>() {

            int obecny = start;


            public boolean hasNext() {
                return obecny < koniec;
            }


            public Character next() {
                Character obecnyznak = napis.charAt(obecny);
                obecny += krok;
                return obecnyznak;
            }
        };
    }



}
