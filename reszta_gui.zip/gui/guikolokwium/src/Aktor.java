public class Aktor extends Artysta{
    int zagranerole;
    public Aktor(String nazwisko,double rocznydochod,int zagranerole){
        super(nazwisko,rocznydochod);
        this.zagranerole=zagranerole;

    }
    public String toString(){
        return   super.toString()+" "+zagranerole;
    }
    public int compareTo(Aktor o){
        if(this.rocznydochod-o.rocznydochod<0){
            return 1;
        }
        if(this.rocznydochod-o.rocznydochod>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return 1;
        }
        if(this.zagranerole-o.zagranerole<0){
            return 1;
        }
        if(this.zagranerole-o.zagranerole>0){
            return -1;
        }
        else if(this.numer-o.numer<0){
            return 1;
        }
        else if(this.numer-o.numer>0){
            return -1;
        }
        return 0;
    }
}
