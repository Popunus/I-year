public class Grafik extends Artysta {
    String technikadruku;
    public Grafik(String nazwisko,double rocznydochod,String  technikadruku){
        super(nazwisko,rocznydochod);
        this.technikadruku=technikadruku;
    }
    public String toString(){
        return   super.toString()+" "+technikadruku;
    }
    public int compareTo(Grafik o){
        if(this.rocznydochod-o.rocznydochod<0){
            return 1;
        }
        if(this.rocznydochod-o.rocznydochod>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return 1;
        }
        if(this.technikadruku-o.technikadruku<0){
            return 1;
        }
        if(this.technikadruku-o.technikadruku>0){
            return -1;
        }
        else if(this.numer-o.numer<0){
            return 1;
        }
        else if(this.numer-o.numer>0){
            return -1;
        }
        return 0;
    }
}
