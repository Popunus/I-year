public class Artysta implements Comparable<Artysta>{
    String nazwisko;
    double rocznydochod;
    int numer=0;
    public Artysta(String nazwisko,double rocznydochod){
        numer++;
    }
    public int []alphabet(){
        String a=this.nazwisko;
        int sum=0;
        int tab[]=new int[a.length()];
        for(int i=0;i<a.length();i++){
            tab[i]=(int)(a.charAt(sum));
            sum++;
        }
        return tab;
    }

    public String toString(){
        return nazwisko+" "+rocznydochod+" "+numer;
    }


    public int compareTo(Artysta o) {
        if(this.rocznydochod-o.rocznydochod<0){
            return 1;
        }
        if(this.rocznydochod-o.rocznydochod>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return 1;
        }
        else if(this.numer-o.numer<0){
            return 1;
        }
        else if(this.numer-o.numer>0){
            return -1;
        }
        else return 0;

    }
}
