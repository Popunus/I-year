import java.lang.reflect.Array;
import java.util.Arrays;

public class main {
    public static void main(String[] args) {
        Artysta dziad=new Artysta("dsads",40);
        Artysta rad=new Artysta("tweewt",32);
        Artysta ewq=new Artysta("dassda",10);
        Grafik rww=new Grafik("ghdgh",40,"saddsa");
        Grafik dsa=new Grafik("trew",32,"dassda");
        Grafik thg=new Grafik("bvcx",21,"sdadsa");
        Aktor rew=new Aktor("werewr",4,3);
        Aktor vcx=new Aktor("dassda",213,2);
        Aktor zxc=new Aktor("fvdsfr",44,1);
        Artysta tab[]={dziad,rad,ewq};
        Grafik tab2[]={rww,dsa,thg};
        Aktor tab3[]={rew,vcx,zxc};
        Artysta tab4[]={dziad,rww,zxc};
        Arrays.sort(tab);
        Arrays.sort(tab2);
        Arrays.sort(tab3);
        Arrays.sort(tab4);
        for(int i=0;i<3;i++){
            System.out.println(tab[i]);
        }
        for(int i=0;i<3;i++){
            System.out.println(tab2[i]);
        }
        for(int i=0;i<3;i++){
            System.out.println(tab3[i]);
        }
        for(int i=0;i<3;i++){
            System.out.println(tab4[i]);
        }


    }
}
public class Artysta implements Comparable<Artysta>{
    String nazwisko;
    double rocznydochod;
    int numer=0;
    public Artysta(String nazwisko,double rocznydochod){
        numer++;
    }
    public int []alphabet(){
        String a=this.nazwisko;
        int sum=0;
        int tab[]=new int[a.length()];
        for(int i=0;i<a.length();i++){
            tab[i]=(int)(a.charAt(sum));
            sum++;
        }
        return tab;
    }

    public String toString(){
        return nazwisko+" "+rocznydochod+" "+numer;
    }


    public int compareTo(Artysta o) {
        if(this.rocznydochod-o.rocznydochod<0){
            return 1;
        }
        if(this.rocznydochod-o.rocznydochod>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return 1;
        }
        else if(this.numer-o.numer<0){
            return 1;
        }
        else if(this.numer-o.numer>0){
            return -1;
        }
        else return 0;

    }
}
public class Aktor extends Artysta{
    int zagranerole;
    public Aktor(String nazwisko,double rocznydochod,int zagranerole){
        super(nazwisko,rocznydochod);
        this.zagranerole=zagranerole;
        numer++;

    }
    public String toString(){
        return   super.toString()+" "+zagranerole;
    }
    public int compareTo(Aktor o){
        if(this.rocznydochod-o.rocznydochod<0){
            return 1;
        }
        if(this.rocznydochod-o.rocznydochod>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return 1;
        }
        if(this.zagranerole-o.zagranerole<0){
            return 1;
        }
        if(this.zagranerole-o.zagranerole>0){
            return -1;
        }
        else if(this.numer-o.numer<0){
            return 1;
        }
        else if(this.numer-o.numer>0){
            return -1;
        }
        return 0;
    }
}
public class Grafik extends Artysta {
    String technikadruku;
    public Grafik(String nazwisko,double rocznydochod,String  technikadruku){
        super(nazwisko,rocznydochod);
        this.technikadruku=technikadruku;
        numer++;
    }
    public String toString(){
        return   super.toString()+" "+technikadruku;
    }
    public int compareTo(Grafik o){
        if(this.rocznydochod-o.rocznydochod<0){
            return 1;
        }
        if(this.rocznydochod-o.rocznydochod>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return -1;
        }
        if(this.alphabet()-o.alphabet()>0){
            return 1;
        }
        if(this.technikadruku-o.technikadruku<0){
            return 1;
        }
        if(this.technikadruku-o.technikadruku>0){
            return -1;
        }
        else if(this.numer-o.numer<0){
            return 1;
        }
        else if(this.numer-o.numer>0){
            return -1;
        }
        return 0;
    }
}
