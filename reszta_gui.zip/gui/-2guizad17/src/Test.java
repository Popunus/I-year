import javax.swing.*;
import java.awt.*;
import javax.swing.JButton;
import javax.swing.JFrame;
public class Test {
    public static void main(String[] args) {
        new Test();
    }
    public Test()
    {
        SwingUtilities.invokeLater(
                () -> createGUI()
        );
    }

    protected void createGUI()
    {
        String x = JOptionPane.showInputDialog("Podaj literke od A-G by zobaczyc odpowedni Layout");

        JFrame jf = new JFrame();

        jf.setTitle("zadanie 16");


        Container container = jf.getContentPane();

        container.add(new JButton("Przycisk 1"));
        container.add(new JButton("P 2"));
        container.add(new JButton("WiÄ™kszy przycisk numer 3"));
        container.add(new JButton("Przycisk 4"));
        container.add(new JButton("P5"));

        switch(x){
            case "A"-> {
                int counter=0;
                for(Component c : container.getComponents()) {
                    if(c instanceof JButton){
                        if(counter==0) {
                            JButton tako = (JButton) c;
                            container.add(tako, BorderLayout.WEST);
                        }
                        if(counter==1) {
                            JButton tako = (JButton) c;
                            container.add(tako, BorderLayout.NORTH);
                        }
                        if(counter==2) {
                            JButton tako = (JButton) c;
                            container.add(tako, BorderLayout.SOUTH);
                        }
                        if(counter==3) {
                            JButton tako = (JButton) c;
                            container.add(tako, BorderLayout.EAST);
                        }
                        if(counter==4) {
                            JButton tako = (JButton) c;
                            container.add(tako, BorderLayout.CENTER);
                        }
                        counter++;
                    }
                }
            }
            case "B"-> container.setLayout(new FlowLayout());
            case "C"-> container.setLayout(new FlowLayout(FlowLayout.LEFT));
            case "D"-> container.setLayout(new FlowLayout(FlowLayout.RIGHT));
            case "E"-> {
                container.setLayout(new GridLayout());
                for(Component c : container.getComponents())
                c.setMaximumSize( c.getPreferredSize() );
            }
            case "F"-> container.setLayout(new GridLayout(container.getComponentCount(),1));
            case "G"-> container.setLayout(new GridLayout(3,2));
            default ->{
                System.out.println("niepoprawny znak");

            }

        }
// PROBLEM z a, e albo g niezrobione f




        jf.setSize(500,500);
        jf.setLocation(500, 300);
        jf.pack();
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setResizable(true);

        jf.setVisible(true);
    }
}
