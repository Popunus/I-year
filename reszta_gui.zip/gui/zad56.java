abstract class Figura implements Obliczanie {

    private  int x;
    private  int y;

    // konstruktor
    public Figura(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // metody abstrakcyjne
    public abstract String fig();

    public abstract void pozycja(int x, int y);

    @Override
    public String toString() {
        return getClass().getName();
    }

    public int getY() {
        return y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
}


class Kolo extends Figura implements Obliczanie {

    private  int promien;

    // konstruktor
    public Kolo(int x, int y, int r) {
        super(x, y);
        this.promien = r;
    }


    @Override
    public String fig() {
        return "Koło";
    }

    @Override
    public void pozycja(int x, int y) {
        //odleglosc punktow
        double distance = Math.sqrt((Math.pow(x - getX(), 2) + Math.pow(y - getY(), 2)));
        if (distance > promien)
            System.out.println("\nPunkt (" + x + "," + y + ")  znajduje się na zwewnątrz koła");
        else
            System.out.println("\nPunkt (" + x + "," + y + ")  znajduje się wewnątrz koła");
    }

    @Override
    public String toString() {
        return super.toString() + "\nSrodek - (" + getX() + ',' + getY() + ")" + "\nPromien: " + promien + "\n" + "Pole:" + pole() + "\nObwod:" + obwod() + "\n";
    }

    @Override
    public double pole() {
        double wynik;
        wynik = Math.PI * Math.pow(promien, 2);
        return wynik;
    }

    @Override
    public double obwod() {
        double wynik;
        wynik = 2 * Math.PI * promien;
        return wynik;
    }
}

class Prostokat extends Figura implements Obliczanie {

    protected int szer, wys;

    public int getSzer() {
        return szer;
    }

    public int getWys() {
        return wys;
    }

    // konstruktor
    public Prostokat(int x, int y, int s, int w) {
        super(x, y);
        this.szer = s;
        this.wys = w;
    }

    @Override
    public String fig() {
        return "Prostokat";
    }

    @Override
    public void pozycja(int x, int y) {
        if ((x <= getX() && x > getX() - szer) && (y <= getY() && x > getY() - y))
            System.out.println("\nPunkt (" + x + "," + y + ")  znajduje się wewnątrz prostokata");
        else
            System.out.println("\nPunkt (" + x + "," + y + ")  znajduje się na zewnątrz prostokata");
    }

    @Override
    public String toString() {
        return super.toString() + "\nLewy górny - (" + getX() + ',' + getY() + ")" + "\nSzerokość: " + szer + ", " + "Wysokość: " + wys + "\nPole:" + pole() + "\nObwod:" + obwod() + "\n";
    }

    @Override
    public double pole() {
        return szer * wys;
    }

    @Override
    public double obwod() {
        return ((2 * szer) + (2 * wys));
    }
}

class Prostokat2 extends Prostokat implements Rysowanie {
    private final char znak;

    public Prostokat2(int x, int y, int s, int w, char znak) {
        super(x, y, s, w);
        this.znak = znak;
    }

    @Override
    public void rysuj() {
        System.out.println("\nRysowanie prostokata \nszerokosc:" + getSzer() + "\nwysokosc:" + getWys());
        for (int i = 0; i < wys; i++) {
            for (int j = 0; j < szer; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
class Kolo2 extends Kolo implements Transformacja{
    int zmiennaX, zmiennaY,zmiennaPromien;


    Kolo2(int x, int y, int promien){
        super(x,y,promien);
        zmiennaPromien=promien;
        zmiennaX=x;
        zmiennaY=y;

    }

    @Override
    public void przesunDo(int x, int y) {
        this.setX(x);
        this.setY(y);

    }

    @Override
    public void powrot() {
        this.setX(zmiennaX);
        this.setY(zmiennaY);
    }
}

interface Obliczanie {
    double pole();

    double obwod();
}

interface Rysowanie {
    void rysuj();
}

interface Transformacja {
    void przesunDo(int x, int y);
    void powrot();
}

public class Test {

    public static void main(String[] args) {
        Figura[] fig = new Figura[2];
        fig[0] = new Kolo(10, 10, 5);                    // położenie koła = srodek = (10,10), promień = 5
        fig[1] = new Prostokat(20, 20, 15, 10);    // położenie prostokąta = lewy górny wierzchołek = (20,20), szerokość = 15, wysokość = 10

        // polimorficzne wywołanie metody toString() z klas Kolo/Prostokat,
        // a nie z klasy Figura
        for (Figura f : fig)              // pętla for-each
            System.out.println(f);    // System.out.println(f.toString());

        fig[0].pozycja(12, 12);
        fig[1].pozycja(25, 30);

        Figura p2 = new Prostokat2(20, 20, 10, 5, '*');
        ((Prostokat2) p2).rysuj();
        //p2.rysuj() nie dziala bo bo rysuj() nie ma w klasie Prostokat

        Kolo2 k2 = new Kolo2(15, 20, 5);

        k2.przesunDo(50, 40);    // przesunięcie środka koła do punktu (50, 40)
        System.out.println(k2);

        k2.powrot();                    // powrót do poprzedniej pozycji (bezpośrednio przed przesunięciem) środka koła
        System.out.println(k2);
    }
}