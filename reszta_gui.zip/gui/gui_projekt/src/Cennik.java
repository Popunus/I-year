import java.util.*;
public class Cennik {
    private static Cennik instance = null;
    private String name;
    private static int going_up=0;
    private Cennik(String name) {
        this.name = name;
    }
    LinkedHashMap<Integer, Integer> map1 = new LinkedHashMap<>();
    LinkedHashMap<String, String> map2 = new LinkedHashMap<>();




    public static Cennik pobierzCennik() {
        if (instance == null) {
            instance = new Cennik("cennik");
        }

        return instance;
    }

    public void dodaj(String pokoj, String typ, int cena_noc, int cena_sniadanie) {
        map2.put(pokoj,typ);
        map1.put(cena_noc,cena_sniadanie);

    }


}