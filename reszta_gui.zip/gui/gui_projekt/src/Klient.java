import java.util.*;

public class Klient extends ListaZyczen {
    String imie;
    int budzet;
    int zaplacone=0;

    ArrayList< Pokoje > map_klient = new ArrayList<>();
    ArrayList< Pokoje > mapa_pozaplacie = new ArrayList<>();

    public Klient(String imie,int budzet){
        this.imie=imie;
        this.budzet=budzet;
    }


    public void dodaj(Pokoje a) {
        map_klient.add(a);

    }

    public ListaZyczen pobierzListeZyczen(){
        ListaZyczen k2=new ListaZyczen();
        k2.lista_cel=map_klient;

        return k2 ;
    }
    public ArrayList<Pokoje> zaplac(String sposob_platnosci){
        String check=sposob_platnosci;
        int ilemamy=budzet;
        ArrayList<Pokoje> temp=new ArrayList<>();
        Koszyk b=new Koszyk(this);
        ArrayList< Pokoje > temp_for_koszyk=b.lista_kosz;
        LinkedHashMap<String, String> cennik2 = Cennik.pobierzCennik().map2; //pobieramy cennik ktory zostal podzielony na dwie czesci
        LinkedHashMap<Integer, Integer> cennik1 = Cennik.pobierzCennik().map1;

        Integer[] cena_noc = new Integer[cennik1.size()];//wartosci z linkedhashmapy przenosimy do tablic

        Integer[] cena_sniadanie = new Integer[cennik1.size()];
        int i = 0;

        for (Map.Entry mapElement : cennik1.entrySet()) {
            int key = (int) mapElement.getKey();

            int value = ((int) mapElement.getValue());

            cena_noc[i] = key;
            cena_sniadanie[i] = value;
            i++;
        }

        String[] pokoj = new String[cennik2.size()];

        String[] typ = new String[cennik2.size()];
        int j = 0;

        for (Map.Entry mapElement : cennik2.entrySet()) {
            String key = (String) mapElement.getKey();

            String value = ((String) mapElement.getValue());

            pokoj[j] = key;
            typ[j] = value;
            j++;
        }
        //petla sprawdza czy pokoj jest w cenniku
        for (Pokoje a : temp_for_koszyk) {
            for (int o = 0; o < cena_noc.length; o++) {
                if (a.getClas().equals(pokoj[o])) {
                    if (a.typ.equals(typ[o])) {
                        if(cena_noc[o]*a.ile_nocy>ilemamy) { //jezeli nie mamy wystarczajcej liczby pieniedzy to zmniejszamy ilosc nocy
                            for(int q=a.ile_nocy-1;q>0;q--){
                                if(cena_noc[o]*q<ilemamy){
                                    a.ile_nocy=q;
                                    break;
                                }
                            }

                        }
                        if(cena_noc[o]*a.ile_nocy<ilemamy) {
                            ilemamy -= cena_noc[o] * a.ile_nocy;
                            if (a.czy_sniadanie) {
                                if (cena_sniadanie[o] * a.ile_nocy < ilemamy) {
                                    ilemamy -= cena_sniadanie[o] * a.ile_nocy;
                                    temp.add(a);
                                }


                            }
                            if (!a.czy_sniadanie)
                                temp.add(a);
                        }



                    }
                }
            }
        }

        if(check=="przelew")
            ilemamy-=5;
        //sprawdzenie czy elementy sa takie same jezeli tak to usuwamy
        for (Pokoje element : temp_for_koszyk) {


            if (!temp.contains(element)) {

                temp.remove(element);
            }
        }



        zaplacone=ilemamy;
        mapa_pozaplacie=temp;
        return mapa_pozaplacie;



    }

    public ArrayList<Pokoje> przepakuj(Koszyk kosz) {
        ArrayList<Pokoje> temp=this.pobierzListeZyczen().lista_cel;
        ArrayList<Pokoje> destiny = new ArrayList<>();
        LinkedHashMap<String,String> zmienna=Cennik.pobierzCennik().map2;
        //jezeli dane zgadzaja sie z cennikiem to pobieramy je
        for(Pokoje a:temp){
            if(zmienna.containsKey(a.getClas()))
                if(zmienna.get(a.getClas()).equals(a.typ))
                    destiny.add(a);




        }

        return destiny;
    }

    public int pobierzPortfel() {
        return zaplacone;
    }

    public Koszyk pobierzKoszyk() {
        Koszyk k2 = new Koszyk(this);
        if(zaplacone!=0)
            k2.lista_kosz = mapa_pozaplacie;
        else
            k2.lista_kosz=map_klient;
        return k2;
    }

}