import java.util.ArrayList;
import java.util.Arrays;

public class Koszyk {
    ArrayList< Pokoje > lista_kosz = new ArrayList<>();
    public Koszyk(Klient a){
        lista_kosz=a.przepakuj(this);
    }

    @Override
    public String toString() {
        return Arrays.asList(lista_kosz).toString();
    }

}