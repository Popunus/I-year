import java.awt.*;
import javax.swing.*;
public class Main {
    public static void main(String[] args) {
        JFrame frame= new JFrame("Pierwsze gui");
        frame.setResizable(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(new Color(0, 204, 0));
        frame.setLayout(new FlowLayout());
        JTextArea textArea=new JTextArea("przykladowy tekst");
        textArea.setForeground(Color.red);
        textArea.setBackground(new Color(0, 204, 0));
        frame.add(textArea);
        Font font = new Font(Font.DIALOG,Font.BOLD,14);
        textArea.setFont(font);
        frame.pack();
        textArea.setVisible(true);
        frame.setVisible(true);
        frame.setSize(600,600);

    }
}
