import java.util.ArrayList;
import java.util.*;

class ArrayBox <T extends Comparable> {
    int size;
    Object[] arr;

    public ArrayBox(int a) {
        arr = new Object[a];

    }

    public boolean add(T o) {
        int index = 0;
        int czydodajemy = 0;
        boolean czyDodano = false;
        for (Object szukany : arr) {
            if (o == arr[index]) {
                czydodajemy++;
            } else
                index++;
        }
        if (czydodajemy == 0) {
            if (size >= arr.length) {
                Object[] newElements = new Object[size + 1];
                for (int i = 0; i < size; i++) {
                    newElements[i] = arr[i];

                }
                arr = newElements;
            }
            arr[size] = o;
            size++;
            czyDodano = true;

        }
        return czyDodano;
    }

    boolean addAll(T[] array) {

        Object[] newElements;
        boolean czyDodano = false;
        for (int j = 0; j < array.length; j++) {
            newElements = new Object[size + 1];
            for (int i = 0; i < size; i++) {
                newElements[i] = arr[i];
                arr = newElements;
            }

            arr[size] = array[j];
            size++;
            czyDodano = true;
        }
        return czyDodano;
    }

    boolean remove(T h) {
        boolean wpp = false;
        int index = 0;
        for (Object szukany : arr) {
            if (h == arr[index]) {
                Object[] newElements = new Object[size - 1];
                for (int i = 0; i < size; i++) {
                    if (h != arr[i]) {
                        newElements[i] = arr[i];
                        arr = newElements;
                    }
                }
                wpp = true;
                return wpp;
            } else
                index++;
        }
        return wpp;
    }

    boolean swap(int left, int right) {
        Object temp, temp2;
        temp = arr[left];
        temp2 = arr[right];
        for (int i = 0; i < arr.length; i++) {
            if (i == left) {
                arr[i] = temp2;
            }
            if (i == right) {
                arr[i] = temp;
                return true;
            }
        }
        return false;
    }

    int search(T d) {

        for (int i = 0; i < arr.length; i++) {
            if (d==(T)arr[i]) {
                return i;
            }

        }

        return -1;
    }

    void print() {

        for (int i=0;i<size;i++)
            System.out.println(arr[i]);
        System.out.println();
    }

    T min() {
        T min = (T) this.arr[0];
        for (int i = 0; i < arr.length; i++) {
            if ((((T) arr[i]).compareTo(min) < 0))
                min = (T) arr[i];
        }
        return min;
    }

    T max() {
        T max = (T) arr[0];
        for (int i = 0; i < arr.length; i++) {
            if ((((T) arr[i]).compareTo(max) > 0))
                max = (T) arr[i];
        }
        return max;
    }
}

class Osoba implements Comparable<Osoba> {
    private String nazwisko;
    private int wiek;

    public Osoba(String nazwisko,int wiek){
        this.nazwisko=nazwisko;
        this.wiek=wiek;
    }
    public String getNazwisko(){
        return nazwisko;

    }

    public int getWiek() {
        return wiek;
    }

    public String toString()
    {
        return getNazwisko()+" "+ getWiek();
    }

    // porównujemy 2 obiekty this, o
    // można korzystać z compareTo(...) z klasy String
    public int compareTo(Osoba o) {
        if (this.getNazwisko().compareTo(o.getNazwisko()) < 0)
            return -1;
        else if (this.getNazwisko().compareTo(o.getNazwisko()) > 0)
            return 1;
        if (this.wiek - o.wiek < 0)
            return -1;
        else if (this.wiek - o.wiek > 0)
            return 1;
        else
            return 0;
    }

}


class Student extends Osoba
{
    private int numerGrupy;

    public Student(String nazwisko,int wiek, int numerGrupy){
       super(nazwisko,wiek);
       this.numerGrupy=numerGrupy;
   }

    public int getNumerGrupy() {
        return numerGrupy;
    }
    public String toString()
    {
        return getNazwisko()+" "+ getWiek()+" "+numerGrupy;
    }

    public int compareTo(Osoba o)
    {
        if (this.getNazwisko().compareTo(o.getNazwisko()) < 0)
            return -1;
        else if (this.getNazwisko().compareTo(o.getNazwisko()) > 0)
            return 1;
        if (this.getWiek() - o.getWiek() < 0)
            return -1;
        else if (this.getWiek() - o.getWiek() > 0)
            return 1;
        Student s = (Student)o;
        if (this.numerGrupy - s.numerGrupy < 0)
            return -1;
        else if (this.numerGrupy - s.numerGrupy > 0)
            return 1;
        else
            return 0;
        // porównujemy 2 obiekty: this, o

        // jeśli o jest typu Student to
        // Student s = (Student)o;
        // ... s.nrGrupy()...
        // ...
        // jeśli o jest tylko typu Osoba
        // ...
    }

}